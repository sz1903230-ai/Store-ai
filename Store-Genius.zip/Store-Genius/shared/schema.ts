import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Shopify stores connected by users
export const stores = pgTable("stores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shopDomain: text("shop_domain").notNull().unique(),
  accessToken: text("access_token").notNull(),
  shopName: text("shop_name").notNull(),
  email: text("email"),
  currency: text("currency").default("USD"),
  timezone: text("timezone"),
  healthScore: integer("health_score").default(0),
  totalProducts: integer("total_products").default(0),
  activeIssues: integer("active_issues").default(0),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const storesRelations = relations(stores, ({ many }) => ({
  products: many(products),
  issues: many(issues),
  improvements: many(improvements),
}));

// Products synced from Shopify
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  shopifyId: text("shopify_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  handle: text("handle"),
  vendor: text("vendor"),
  productType: text("product_type"),
  tags: text("tags").array(),
  status: text("status").default("active"),
  imageUrl: text("image_url"),
  images: jsonb("images").$type<string[]>(),
  price: text("price"),
  compareAtPrice: text("compare_at_price"),
  inventoryQuantity: integer("inventory_quantity").default(0),
  hasDescription: boolean("has_description").default(false),
  hasImages: boolean("has_images").default(false),
  hasTags: boolean("has_tags").default(false),
  badges: jsonb("badges").$type<Array<{type: string; text: string; color: string}>>(),
  seoScore: integer("seo_score").default(0),
  aiScore: integer("ai_score").default(0),
  optimizationScore: integer("optimization_score").default(0),
  lastAnalyzedAt: timestamp("last_analyzed_at"),
  lastOptimizedAt: timestamp("last_optimized_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const productsRelations = relations(products, ({ one, many }) => ({
  store: one(stores, {
    fields: [products.storeId],
    references: [stores.id],
  }),
  issues: many(issues),
  improvements: many(improvements),
  bundleSuggestions: many(bundleSuggestions),
}));

// Issues detected on products
export const issues = pgTable("issues", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  productId: varchar("product_id").references(() => products.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // missing_description, missing_images, missing_tags, low_seo, etc
  severity: text("severity").notNull().default("medium"), // low, medium, high, critical
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").default("open"), // open, in_progress, resolved, ignored
  autoFixable: boolean("auto_fixable").default(false),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const issuesRelations = relations(issues, ({ one }) => ({
  store: one(stores, {
    fields: [issues.storeId],
    references: [stores.id],
  }),
  product: one(products, {
    fields: [issues.productId],
    references: [products.id],
  }),
}));

// AI-generated improvements
export const improvements = pgTable("improvements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  productId: varchar("product_id").references(() => products.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // description, title, tags, banner, seo
  originalContent: text("original_content"),
  improvedContent: text("improved_content").notNull(),
  confidence: real("confidence").default(0.8),
  status: text("status").default("pending"), // pending, applied, rejected
  appliedAt: timestamp("applied_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const improvementsRelations = relations(improvements, ({ one }) => ({
  store: one(stores, {
    fields: [improvements.storeId],
    references: [stores.id],
  }),
  product: one(products, {
    fields: [improvements.productId],
    references: [products.id],
  }),
}));

// Bundle suggestions
export const bundleSuggestions = pgTable("bundle_suggestions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  productId: varchar("product_id").references(() => products.id, { onDelete: "cascade" }),
  suggestedProductIds: text("suggested_product_ids").array(),
  bundleName: text("bundle_name"),
  bundleDescription: text("bundle_description"),
  discountPercentage: integer("discount_percentage").default(10),
  confidence: real("confidence").default(0.7),
  status: text("status").default("pending"), // pending, applied, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

export const bundleSuggestionsRelations = relations(bundleSuggestions, ({ one }) => ({
  store: one(stores, {
    fields: [bundleSuggestions.storeId],
    references: [stores.id],
  }),
  product: one(products, {
    fields: [bundleSuggestions.productId],
    references: [products.id],
  }),
}));

// Banner recommendations
export const bannerRecommendations = pgTable("banner_recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storeId: varchar("store_id").notNull().references(() => stores.id, { onDelete: "cascade" }),
  productId: varchar("product_id").references(() => products.id, { onDelete: "cascade" }),
  bannerType: text("banner_type").notNull(), // sale, new_arrival, limited, bestseller
  headline: text("headline").notNull(),
  subheadline: text("subheadline"),
  ctaText: text("cta_text"),
  confidence: real("confidence").default(0.75),
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Users table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Insert schemas
export const insertStoreSchema = createInsertSchema(stores).omit({ id: true, createdAt: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true, updatedAt: true });
export const insertIssueSchema = createInsertSchema(issues).omit({ id: true, createdAt: true });
export const insertImprovementSchema = createInsertSchema(improvements).omit({ id: true, createdAt: true });
export const insertBundleSuggestionSchema = createInsertSchema(bundleSuggestions).omit({ id: true, createdAt: true });
export const insertBannerRecommendationSchema = createInsertSchema(bannerRecommendations).omit({ id: true, createdAt: true });
export const insertUserSchema = createInsertSchema(users).pick({ username: true, password: true });

// Types
export type Store = typeof stores.$inferSelect;
export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Issue = typeof issues.$inferSelect;
export type InsertIssue = z.infer<typeof insertIssueSchema>;
export type Improvement = typeof improvements.$inferSelect;
export type InsertImprovement = z.infer<typeof insertImprovementSchema>;
export type BundleSuggestion = typeof bundleSuggestions.$inferSelect;
export type InsertBundleSuggestion = z.infer<typeof insertBundleSuggestionSchema>;
export type BannerRecommendation = typeof bannerRecommendations.$inferSelect;
export type InsertBannerRecommendation = z.infer<typeof insertBannerRecommendationSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
