# StoreFix AI - Shopify Store Manager

## Overview

StoreFix AI is an AI-powered Shopify store management platform that automatically detects product issues, analyzes product quality, and generates intelligent recommendations for store optimization. The application integrates with Shopify stores to sync product data, identify problems (missing descriptions, images, tags, poor SEO), and provide AI-driven improvements including enhanced descriptions, optimized tags, bundle suggestions, and banner recommendations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18 with TypeScript for type-safe component development
- Vite as the build tool and development server for fast HMR and optimized production builds
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for server state management, caching, and data synchronization

**UI Component System**
- Radix UI primitives for accessible, headless component foundations
- shadcn/ui component library following "New York" style variant
- Tailwind CSS for utility-first styling with custom design tokens
- Design system inspired by Shopify Polaris with Linear-style refinement for professional SaaS dashboard aesthetics
- Custom CSS variables for theming with light/dark mode support via ThemeProvider context

**State Management Pattern**
- Server state handled by React Query with invalidation-based cache updates
- Local UI state managed with React hooks
- Theme state persisted to localStorage and managed via context

**Key Layout Decisions**
- Collapsible sidebar navigation (16rem expanded, 3rem collapsed) with mobile sheet overlay
- Responsive grid layouts (1/2/3 columns) for dashboard cards and product displays
- Path aliases configured for clean imports (@/, @shared/, @assets/)

### Backend Architecture

**Server Framework**
- Express.js with TypeScript for the REST API layer
- Custom request/response logging middleware for debugging and monitoring
- Production-ready error handling and validation

**API Design Pattern**
- RESTful API structure organized by resource (/api/stores, /api/products, /api/issues, /api/improvements, /api/bundles, /api/banners)
- Request validation using Zod schemas derived from database schema
- Response standardization with JSON payloads
- Mutation endpoints for applying AI suggestions (POST /api/improvements/:id/apply, etc.)

**Data Access Layer**
- Storage interface pattern (IStorage) abstracting database operations
- Drizzle ORM for type-safe database queries and schema management
- Relational schema with cascading deletes for data integrity
- Separate update types for partial updates with strict typing

**AI Integration Architecture**
- OpenAI API integration for product analysis, content generation, and recommendations
- Modular AI functions: analyzeProduct, generateDescription, generateTags, generateBundleSuggestion, generateBannerRecommendation, fixIssue
- Confidence scoring for AI-generated suggestions
- Structured output types matching database schema for seamless persistence

### Database Design

**ORM & Migration Strategy**
- Drizzle ORM with PostgreSQL dialect
- Schema-first approach with TypeScript types generated from database schema
- Drizzle Kit for migrations (schema location: shared/schema.ts, migrations output: ./migrations)
- Database URL required via DATABASE_URL environment variable

**Core Schema Entities**
- **stores**: Shopify store connections with health metrics (healthScore, totalProducts, activeIssues)
- **products**: Synced product data with quality scores (seoScore, aiScore) and feature flags (hasDescription, hasImages, hasTags)
- **issues**: Detected product problems with severity levels (critical/high/medium/low) and auto-fix capability flags
- **improvements**: AI-generated suggestions with confidence scores, before/after data, and application tracking
- **bundleSuggestions**: Product bundle recommendations with discount percentages
- **bannerRecommendations**: Marketing banner suggestions with copy and CTA text

**Relationships**
- One-to-many: Store → Products, Store → Issues, Store → Improvements
- Product-linked: Issues, Improvements, BundleSuggestions, BannerRecommendations reference products
- Cascading deletes maintain referential integrity when stores or products are removed

**Schema Validation**
- Zod schemas generated via drizzle-zod for runtime validation
- Insert schemas derived from table definitions ensure type safety at API boundaries

### External Dependencies

**AI Service**
- OpenAI API for GPT-based product analysis and content generation
- API key required via OPENAI_API_KEY environment variable
- Used for: product quality scoring, issue detection, description improvement, tag generation, bundle suggestions, banner copy creation

**Database**
- PostgreSQL database (connection via DATABASE_URL)
- Managed via pg Pool for connection pooling
- Required for all data persistence

**Shopify Integration**
- Store connection via shop domain and access token
- Product data synchronization (shopifyId stored for reference)
- Note: Full Shopify API integration appears to be planned/in-progress based on schema fields

**Development Tools**
- Replit-specific plugins for development environment (vite-plugin-cartographer, vite-plugin-dev-banner, vite-plugin-runtime-error-modal)
- Only loaded in non-production Replit environments

**UI Dependencies**
- Google Fonts CDN for Inter (primary) and JetBrains Mono (monospace) typefaces
- Recharts for data visualization and analytics charts
- Heroicons via Lucide React for consistent iconography