import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Sparkles,
  CheckCircle,
  XCircle,
  FileText,
  Tag,
  Megaphone,
  Package,
  ArrowRight,
  Eye,
  RefreshCw
} from "lucide-react";
import { Link } from "wouter";
import type { Improvement, Product, BannerRecommendation } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const improvementTypeConfig = {
  description: { icon: FileText, label: "Description" },
  title: { icon: Package, label: "Title" },
  tags: { icon: Tag, label: "Tags" },
  banner: { icon: Megaphone, label: "Banner" },
  seo: { icon: FileText, label: "SEO" },
};

function ImprovementCard({ 
  improvement, 
  product 
}: { 
  improvement: Improvement; 
  product?: Product;
}) {
  const { toast } = useToast();
  const [showComparison, setShowComparison] = useState(false);
  
  const typeConfig = improvementTypeConfig[improvement.type as keyof typeof improvementTypeConfig] || 
    { icon: Sparkles, label: improvement.type };
  const Icon = typeConfig.icon;

  const applyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/improvements/${improvement.id}/apply`);
    },
    onSuccess: () => {
      toast({ title: "Improvement applied", description: "Changes have been applied to your product" });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/improvements/${improvement.id}`, { status: "rejected" });
    },
    onSuccess: () => {
      toast({ title: "Improvement rejected", description: "Suggestion has been dismissed" });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
    },
  });

  return (
    <Card className="hover-elevate" data-testid={`card-improvement-${improvement.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className="p-2 rounded-md bg-primary/10">
            <Icon className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-base capitalize">{typeConfig.label} Improvement</h3>
              <Badge variant="outline" className="gap-1">
                <Sparkles className="h-3 w-3" />
                {Math.round((improvement.confidence || 0.8) * 100)}% confidence
              </Badge>
            </div>
            
            {product && (
              <Link href={`/products/${product.id}`}>
                <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  <span className="truncate max-w-[250px]">{product.title}</span>
                  <ArrowRight className="h-3 w-3" />
                </div>
              </Link>
            )}

            {showComparison ? (
              <div className="mt-4 space-y-3">
                {improvement.originalContent && (
                  <div className="p-3 rounded-md bg-muted/50 border border-dashed">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Original:</p>
                    <p className="text-sm line-clamp-3">{improvement.originalContent}</p>
                  </div>
                )}
                <div className="p-3 rounded-md bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                  <p className="text-xs font-medium text-green-700 dark:text-green-400 mb-1">Improved:</p>
                  <p className="text-sm">{improvement.improvedContent}</p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                {improvement.improvedContent}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 mt-4 pt-4 border-t">
          <Button 
            size="sm"
            onClick={() => applyMutation.mutate()}
            disabled={applyMutation.isPending}
            className="flex-1"
            data-testid={`button-apply-${improvement.id}`}
          >
            <CheckCircle className="h-3 w-3 mr-1" />
            Apply
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setShowComparison(!showComparison)}
            data-testid={`button-compare-${improvement.id}`}
          >
            <Eye className="h-3 w-3 mr-1" />
            {showComparison ? "Hide" : "Compare"}
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => rejectMutation.mutate()}
            disabled={rejectMutation.isPending}
            data-testid={`button-reject-${improvement.id}`}
          >
            <XCircle className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function BannerCard({ banner, product }: { banner: BannerRecommendation; product?: Product }) {
  const { toast } = useToast();
  
  const bannerStyles = {
    sale: "bg-red-500 text-white",
    new_arrival: "bg-blue-500 text-white",
    limited: "bg-purple-500 text-white",
    bestseller: "bg-green-500 text-white",
  };

  const applyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/banners/${banner.id}/apply`);
    },
    onSuccess: () => {
      toast({ title: "Banner applied", description: "Banner has been applied to your product" });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
  });

  return (
    <Card className="hover-elevate" data-testid={`card-banner-${banner.id}`}>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className={`p-4 rounded-md text-center ${bannerStyles[banner.bannerType as keyof typeof bannerStyles] || "bg-primary text-primary-foreground"}`}>
            <p className="font-bold text-lg">{banner.headline}</p>
            {banner.subheadline && (
              <p className="text-sm opacity-90 mt-1">{banner.subheadline}</p>
            )}
            {banner.ctaText && (
              <Button size="sm" variant="secondary" className="mt-2">
                {banner.ctaText}
              </Button>
            )}
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="capitalize">{banner.bannerType?.replace("_", " ")}</Badge>
              <Badge variant="secondary">
                {Math.round((banner.confidence || 0.75) * 100)}% confidence
              </Badge>
            </div>
          </div>

          {product && (
            <p className="text-sm text-muted-foreground truncate">
              For: {product.title}
            </p>
          )}

          <div className="flex gap-2">
            <Button 
              size="sm" 
              className="flex-1"
              onClick={() => applyMutation.mutate()}
              disabled={applyMutation.isPending}
              data-testid={`button-apply-banner-${banner.id}`}
            >
              Apply Banner
            </Button>
            <Button size="sm" variant="outline" data-testid={`button-customize-banner-${banner.id}`}>
              Customize
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Insights() {
  const { data: improvements, isLoading: improvementsLoading } = useQuery<Improvement[]>({
    queryKey: ["/api/improvements"],
  });

  const { data: banners, isLoading: bannersLoading } = useQuery<BannerRecommendation[]>({
    queryKey: ["/api/banners"],
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const productMap = new Map(products?.map(p => [p.id, p]) || []);

  const pendingImprovements = improvements?.filter(i => i.status === "pending") || [];
  const appliedImprovements = improvements?.filter(i => i.status === "applied") || [];
  const pendingBanners = banners?.filter(b => b.status === "pending") || [];

  return (
    <div className="p-6 space-y-6" data-testid="page-insights">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-insights-title">AI Insights</h1>
          <p className="text-muted-foreground mt-1">
            AI-generated improvements and recommendations for your products
          </p>
        </div>
        <Button variant="outline" data-testid="button-refresh-insights">
          <RefreshCw className="h-4 w-4 mr-2" />
          Generate New Insights
        </Button>
      </div>

      <Tabs defaultValue="improvements" className="space-y-4">
        <TabsList>
          <TabsTrigger value="improvements" data-testid="tab-improvements">
            Improvements ({pendingImprovements.length})
          </TabsTrigger>
          <TabsTrigger value="banners" data-testid="tab-banners">
            Banners ({pendingBanners.length})
          </TabsTrigger>
          <TabsTrigger value="applied" data-testid="tab-applied">
            Applied ({appliedImprovements.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="improvements" className="space-y-4">
          {improvementsLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-40 w-full" />
            ))
          ) : pendingImprovements.length === 0 ? (
            <Card>
              <CardContent className="py-12">
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <Sparkles className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium text-lg">No Pending Improvements</h3>
                  <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                    Analyze your products to generate AI-powered improvement suggestions.
                  </p>
                  <Link href="/products">
                    <Button className="mt-4" data-testid="button-analyze-products">
                      Go to Products
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {pendingImprovements.map((improvement) => (
                <ImprovementCard
                  key={improvement.id}
                  improvement={improvement}
                  product={improvement.productId ? productMap.get(improvement.productId) : undefined}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="banners" className="space-y-4">
          {bannersLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-48 w-full" />
            ))
          ) : pendingBanners.length === 0 ? (
            <Card>
              <CardContent className="py-12">
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <Megaphone className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium text-lg">No Banner Recommendations</h3>
                  <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                    AI will generate promotional banner suggestions based on your products.
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pendingBanners.map((banner) => (
                <BannerCard
                  key={banner.id}
                  banner={banner}
                  product={banner.productId ? productMap.get(banner.productId) : undefined}
                />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="applied" className="space-y-4">
          {appliedImprovements.length === 0 ? (
            <Card>
              <CardContent className="py-12">
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="p-4 rounded-full bg-muted mb-4">
                    <CheckCircle className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-medium text-lg">No Applied Improvements Yet</h3>
                  <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                    Applied improvements will appear here for reference.
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {appliedImprovements.map((improvement) => (
                <Card key={improvement.id} className="opacity-75" data-testid={`card-applied-${improvement.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      <div>
                        <p className="font-medium capitalize">{improvement.type} improvement applied</p>
                        <p className="text-sm text-muted-foreground">
                          Applied {improvement.appliedAt ? new Date(improvement.appliedAt).toLocaleDateString() : "recently"}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
