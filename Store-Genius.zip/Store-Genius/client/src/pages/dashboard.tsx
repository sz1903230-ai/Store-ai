import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Activity, 
  Package, 
  AlertTriangle, 
  Sparkles,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  CheckCircle,
  Clock,
  Zap,
  RefreshCw,
  Store as StoreIcon // Import Store icon and alias it
} from "lucide-react";
import { Link } from "wouter";
import type { Store, Issue, Improvement, Product, DashboardStats } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function MetricCard({
  title,
  value,
  description,
  icon: Icon,
  trend,
  trendValue,
  isLoading,
  testId,
}: {
  title: string;
  value: string | number;
  description: string;
  icon: typeof Activity;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  isLoading?: boolean;
  testId: string;
}) {
  return (
    <Card data-testid={testId}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-24" />
        ) : (
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold">{value}</span>
            {trend && trendValue && (
              <div className={`flex items-center gap-1 text-xs ${
                trend === "up" ? "text-green-600 dark:text-green-400" : 
                trend === "down" ? "text-red-600 dark:text-red-400" : 
                "text-muted-foreground"
              }`}>
                {trend === "up" ? <TrendingUp className="h-3 w-3" /> : 
                 trend === "down" ? <TrendingDown className="h-3 w-3" /> : null}
                {trendValue}
              </div>
            )}
          </div>
        )}
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
      </CardContent>
    </Card>
  );
}

function IssueCard({ issue }: { issue: Issue }) {
  const severityColors = {
    critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    high: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
    medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    low: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  };

  return (
    <div 
      className="flex items-start gap-4 p-4 rounded-md border bg-card hover-elevate"
      data-testid={`card-issue-${issue.id}`}
    >
      <div className={`p-2 rounded-md ${
        issue.severity === "critical" || issue.severity === "high" 
          ? "bg-destructive/10" 
          : "bg-muted"
      }`}>
        <AlertTriangle className={`h-4 w-4 ${
          issue.severity === "critical" || issue.severity === "high"
            ? "text-destructive"
            : "text-muted-foreground"
        }`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-sm">{issue.title}</span>
          <Badge 
            variant="secondary" 
            className={`text-xs ${severityColors[issue.severity as keyof typeof severityColors] || severityColors.medium}`}
          >
            {issue.severity}
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
          {issue.description}
        </p>
      </div>
      {issue.autoFixable && (
        <Button size="sm" variant="default" data-testid={`button-fix-issue-${issue.id}`}>
          <Zap className="h-3 w-3 mr-1" />
          Fix Now
        </Button>
      )}
    </div>
  );
}

function SuggestionCard({ improvement }: { improvement: Improvement }) {
  return (
    <div 
      className="p-4 rounded-md border bg-card hover-elevate"
      data-testid={`card-improvement-${improvement.id}`}
    >
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-md bg-primary/10">
          <Sparkles className="h-4 w-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-sm capitalize">{improvement.type} Improvement</span>
            <Badge variant="outline" className="text-xs">
              {Math.round((improvement.confidence || 0.8) * 100)}% confidence
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
            {improvement.improvedContent?.slice(0, 100)}...
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 mt-3 pt-3 border-t">
        <Button size="sm" variant="default" className="flex-1" data-testid={`button-apply-improvement-${improvement.id}`}>
          <CheckCircle className="h-3 w-3 mr-1" />
          Apply
        </Button>
        <Button size="sm" variant="outline" data-testid={`button-review-improvement-${improvement.id}`}>
          Review
        </Button>
      </div>
    </div>
  );
}

function RecentProductCard({ product }: { product: Product }) {
  const hasIssues = !product.hasDescription || !product.hasImages || !product.hasTags;

  return (
    <div 
      className="flex items-center gap-3 p-3 rounded-md border bg-card hover-elevate"
      data-testid={`card-product-${product.id}`}
    >
      <div className="h-12 w-12 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
        {product.imageUrl ? (
          <img 
            src={product.imageUrl} 
            alt={product.title} 
            className="h-full w-full object-cover"
          />
        ) : (
          <Package className="h-5 w-5 text-muted-foreground" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{product.title}</p>
        <div className="flex items-center gap-2 mt-1">
          {product.price && (
            <span className="text-xs text-muted-foreground">{product.price}</span>
          )}
          {hasIssues && (
            <Badge variant="secondary" className="text-xs bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400">
              Needs attention
            </Badge>
          )}
        </div>
      </div>
      <Link href={`/products/${product.id}`}>
        <Button size="icon" variant="ghost" data-testid={`button-view-product-${product.id}`}>
          <ArrowRight className="h-4 w-4" />
        </Button>
      </Link>
    </div>
  );
}

function EmptyState({ 
  icon: Icon, 
  title, 
  description, 
  action,
  actionLabel,
  testId 
}: {
  icon: typeof Package;
  title: string;
  description: string;
  action?: () => void;
  actionLabel?: string;
  testId: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center" data-testid={testId}>
      <div className="p-4 rounded-full bg-muted mb-4">
        <Icon className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="font-medium text-lg">{title}</h3>
      <p className="text-sm text-muted-foreground mt-1 max-w-sm">{description}</p>
      {action && actionLabel && (
        <Button onClick={action} className="mt-4" data-testid={`${testId}-action`}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}

export default function Dashboard() {
  const { toast } = useToast();

  const { data: stores, isLoading: storesLoading } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: issues, isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: improvements, isLoading: improvementsLoading } = useQuery<Improvement[]>({
    queryKey: ["/api/improvements"],
  });

  const activeStore = stores?.[0];

  const syncMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/stores/${activeStore?.id}/sync`);
    },
    onSuccess: () => {
      toast({ title: "Sync complete", description: "Your store data has been synced" });
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
    },
    onError: (error: Error) => {
      toast({ title: "Sync failed", description: error.message, variant: "destructive" });
    },
  });

  // Fetch dashboard stats with auto-refresh
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  // Track AI analysis progress
  const { data: analysisProgress } = useQuery<{
    total: number;
    completed: number;
    percentage: number;
    isRunning: boolean;
    currentProductId: string | null;
  }>({
    queryKey: ["/api/analysis/progress"],
    refetchInterval: 2000, // Check every 2 seconds
  });

  const healthScore = stats?.healthScore ?? activeStore?.healthScore ?? 0;
  const totalProducts = stats?.totalProducts ?? products?.length ?? 0;
  const openIssues = stats?.openIssues ?? issues?.filter(i => i.status === "open").length ?? 0;
  const pendingImprovements = stats?.pendingImprovements ?? improvements?.filter(i => i.status === "pending").length ?? 0;

  const recentProducts = products?.slice(0, 5) || [];
  const recentIssues = issues?.filter(i => i.status === "open").slice(0, 3) || [];
  const recentImprovements = improvements?.filter(i => i.status === "pending").slice(0, 3) || [];

  const isLoading = storesLoading || productsLoading || issuesLoading || improvementsLoading || statsLoading;
  const hasStore = stores && stores.length > 0;

  if (!hasStore && !storesLoading) {
    return (
      <div className="p-6">
        <EmptyState
          icon={StoreIcon} // Use the aliased icon
          title="Connect Your Shopify Store"
          description="Get started by connecting your Shopify store to unlock AI-powered optimization and automatic issue detection."
          actionLabel="Connect Store"
          action={() => window.location.href = "/settings"}
          testId="empty-no-store"
        />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6" data-testid="page-dashboard">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of your store's health and AI recommendations
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <Clock className="h-3 w-3" />
            Last sync: {activeStore?.lastSyncAt ? new Date(activeStore.lastSyncAt).toLocaleTimeString() : "Never"}
          </Badge>
          <Button 
            onClick={() => syncMutation.mutate()} 
            disabled={syncMutation.isPending || !activeStore}
            data-testid="button-sync-store"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? "animate-spin" : ""}`} />
            {syncMutation.isPending ? "Syncing..." : "Sync Now"}
          </Button>
        </div>
      </div>

      {analysisProgress?.isRunning && (
        <Card className="border-primary">
          <CardContent className="pt-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary animate-pulse" />
                  <span className="font-medium">AI Analysis in Progress</span>
                </div>
                <span className="text-sm font-semibold">{analysisProgress.percentage}%</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${analysisProgress.percentage}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Analyzed {analysisProgress.completed} of {analysisProgress.total} products
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Store Health"
          value={`${healthScore}%`}
          description="Overall optimization score"
          icon={Activity}
          trend={healthScore >= 70 ? "up" : "down"}
          trendValue={healthScore >= 70 ? "Good" : "Needs work"}
          isLoading={isLoading}
          testId="metric-health-score"
        />
        <MetricCard
          title="Total Products"
          value={totalProducts}
          description="Products in your store"
          icon={Package}
          isLoading={isLoading}
          testId="metric-total-products"
        />
        <MetricCard
          title="Active Issues"
          value={openIssues}
          description="Issues requiring attention"
          icon={AlertTriangle}
          trend={openIssues > 5 ? "down" : openIssues > 0 ? "neutral" : "up"}
          trendValue={openIssues === 0 ? "All clear" : `${openIssues} to fix`}
          isLoading={isLoading}
          testId="metric-active-issues"
        />
        <MetricCard
          title="AI Suggestions"
          value={pendingImprovements}
          description="Pending improvements"
          icon={Sparkles}
          isLoading={isLoading}
          testId="metric-ai-suggestions"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2" data-testid="card-recent-issues">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle className="text-xl font-semibold">Recent Issues</CardTitle>
              <CardDescription>Issues detected in your store</CardDescription>
            </div>
            <Link href="/issues">
              <Button variant="outline" size="sm" data-testid="button-view-all-issues">
                View All
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {issuesLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))
            ) : recentIssues.length > 0 ? (
              recentIssues.map((issue) => (
                <IssueCard key={issue.id} issue={issue} />
              ))
            ) : (
              <EmptyState
                icon={CheckCircle}
                title="No Issues Found"
                description="Your store is in great shape! No issues detected."
                testId="empty-no-issues"
              />
            )}
          </CardContent>
        </Card>

        <Card data-testid="card-ai-suggestions">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle className="text-xl font-semibold">AI Suggestions</CardTitle>
              <CardDescription>Ready to apply</CardDescription>
            </div>
            <Link href="/insights">
              <Button variant="ghost" size="icon" data-testid="button-view-all-insights">
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {improvementsLoading ? (
              Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-32 w-full" />
              ))
            ) : recentImprovements.length > 0 ? (
              recentImprovements.map((improvement) => (
                <SuggestionCard key={improvement.id} improvement={improvement} />
              ))
            ) : (
              <EmptyState
                icon={Sparkles}
                title="No Suggestions Yet"
                description="AI suggestions will appear here as products are analyzed."
                testId="empty-no-suggestions"
              />
            )}
          </CardContent>
        </Card>
      </div>

      <Card data-testid="card-recent-products">
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <div>
            <CardTitle className="text-xl font-semibold">Recent Products</CardTitle>
            <CardDescription>Latest products from your store</CardDescription>
          </div>
          <Link href="/products">
            <Button variant="outline" size="sm" data-testid="button-view-all-products">
              View All
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {productsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : recentProducts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {recentProducts.map((product) => (
                <RecentProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={Package}
              title="No Products Yet"
              description="Products will appear here once your store is synced."
              testId="empty-no-products"
            />
          )}
        </CardContent>
      </Card>
    </div>
  );
}