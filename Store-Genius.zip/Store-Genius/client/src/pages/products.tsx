import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Package, 
  Search, 
  Grid3X3, 
  List,
  MoreVertical,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  Image as ImageIcon,
  FileText,
  Tag,
  ExternalLink,
  Eye
} from "lucide-react";
import { Link } from "wouter";
import type { Product } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ViewMode = "grid" | "list";

function ProductStatusBadges({ product }: { product: Product }) {
  const issues = [];
  if (!product.hasDescription) issues.push({ icon: FileText, label: "No description" });
  if (!product.hasImages) issues.push({ icon: ImageIcon, label: "No images" });
  if (!product.hasTags) issues.push({ icon: Tag, label: "No tags" });

  if (issues.length === 0) {
    return (
      <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
        <CheckCircle className="h-3 w-3 mr-1" />
        Optimized
      </Badge>
    );
  }

  return (
    <div className="flex flex-wrap gap-1">
      {issues.map((issue, idx) => (
        <Badge 
          key={idx} 
          variant="secondary" 
          className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
        >
          <issue.icon className="h-3 w-3 mr-1" />
          {issue.label}
        </Badge>
      ))}
    </div>
  );
}

function ProductGridCard({ product }: { product: Product }) {
  const { toast } = useToast();

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${product.id}/analyze`);
    },
    onSuccess: () => {
      toast({ title: "Analysis started", description: "AI is analyzing this product" });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
    },
  });

  const aiOptimizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${product.id}/ai-optimize`);
    },
    onSuccess: (data: any) => {
      toast({ 
        title: "✨ AI Complete!", 
        description: `Badges: ${data.badges?.length || 0} | Bundle: ${data.bundle ? 'Yes' : 'No'} | Banner: ${data.banner ? 'Yes' : 'No'}`
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
  });

  return (
    <Card className="hover-elevate" data-testid={`card-product-${product.id}`}>
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className="h-20 w-20 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
            {product.imageUrl ? (
              <img 
                src={product.imageUrl} 
                alt={product.title} 
                className="h-full w-full object-cover"
              />
            ) : (
              <Package className="h-8 w-8 text-muted-foreground" />
            )}
          </div>
          <div className="flex-1 min-w-0 flex flex-col">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-medium text-sm truncate" data-testid={`text-product-title-${product.id}`}>
                  {product.title}
                </h3>
                <p className="text-xs text-muted-foreground font-mono mt-0.5">
                  {product.shopifyId}
                </p>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="icon" variant="ghost" data-testid={`button-product-menu-${product.id}`}>
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link href={`/products/${product.id}`}>
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View Details
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => analyzeMutation.mutate()}
                    disabled={analyzeMutation.isPending}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Analyze with AI
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => aiOptimizeMutation.mutate()}
                    disabled={aiOptimizeMutation.isPending}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    AI Optimize
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              {product.price && (
                <span className="text-sm font-medium">{product.price}</span>
              )}
              {product.status && (
                <Badge variant="outline" className="text-xs">
                  {product.status}
                </Badge>
              )}
            </div>
            <div className="mt-auto pt-2">
              <ProductStatusBadges product={product} />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ProductTableRow({ product }: { product: Product }) {
  const { toast } = useToast();

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${product.id}/analyze`);
    },
    onSuccess: () => {
      toast({ title: "Analysis started", description: "AI is analyzing this product" });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
    },
  });

  const aiOptimizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${product.id}/ai-optimize`);
    },
    onSuccess: (data: any) => {
      toast({ 
        title: "✨ AI Complete!", 
        description: `Badges: ${data.badges?.length || 0} | Bundle: ${data.bundle ? 'Yes' : 'No'} | Banner: ${data.banner ? 'Yes' : 'No'}`
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
  });

  return (
    <TableRow data-testid={`row-product-${product.id}`}>
      <TableCell>
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
            {product.imageUrl ? (
              <img 
                src={product.imageUrl} 
                alt={product.title} 
                className="h-full w-full object-cover"
              />
            ) : (
              <Package className="h-4 w-4 text-muted-foreground" />
            )}
          </div>
          <div className="min-w-0">
            <p className="font-medium text-sm truncate max-w-[200px]">{product.title}</p>
            <p className="text-xs text-muted-foreground font-mono">{product.shopifyId}</p>
          </div>
        </div>
      </TableCell>
      <TableCell>{product.price || "-"}</TableCell>
      <TableCell>
        <Badge variant="outline">{product.status}</Badge>
      </TableCell>
      <TableCell>{product.inventoryQuantity || 0}</TableCell>
      <TableCell>
        <ProductStatusBadges product={product} />
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1">
          <span className={`text-sm font-medium ${
            (product.aiScore || 0) >= 80 ? "text-green-600 dark:text-green-400" :
            (product.aiScore || 0) >= 50 ? "text-yellow-600 dark:text-yellow-400" :
            "text-red-600 dark:text-red-400"
          }`}>
            {product.aiScore || 0}%
          </span>
        </div>
      </TableCell>
      <TableCell className="text-right">
        <div className="flex items-center justify-end gap-2">
          <Link href={`/products/${product.id}`}>
            <Button size="sm" variant="outline">
              <Eye className="h-3 w-3 mr-1" />
              View
            </Button>
          </Link>
          <Button 
            size="sm" 
            variant="default"
            onClick={() => aiOptimizeMutation.mutate()}
            disabled={aiOptimizeMutation.isPending}
            className="bg-gradient-to-r from-purple-600 to-blue-600"
          >
            <Sparkles className={`h-3 w-3 mr-1 ${aiOptimizeMutation.isPending ? "animate-spin" : ""}`} />
            {aiOptimizeMutation.isPending ? "..." : "AI"}
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

export default function Products() {
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [issueFilter, setIssueFilter] = useState<string>("all");

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = products?.filter((product) => {
    const matchesSearch = product.title.toLowerCase().includes(search.toLowerCase()) ||
      product.shopifyId.includes(search);
    const matchesStatus = statusFilter === "all" || product.status === statusFilter;

    let matchesIssue = true;
    if (issueFilter === "needs_description") matchesIssue = !product.hasDescription;
    if (issueFilter === "needs_images") matchesIssue = !product.hasImages;
    if (issueFilter === "needs_tags") matchesIssue = !product.hasTags;
    if (issueFilter === "optimized") matchesIssue = product.hasDescription && product.hasImages && product.hasTags;

    return matchesSearch && matchesStatus && matchesIssue;
  }) || [];

  return (
    <div className="p-6 space-y-6" data-testid="page-products">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-products-title">Products</h1>
          <p className="text-muted-foreground mt-1">
            Manage and optimize your store products
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setViewMode("grid")} 
            className={viewMode === "grid" ? "bg-muted" : ""}
            data-testid="button-view-grid"
          >
            <Grid3X3 className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => setViewMode("list")}
            className={viewMode === "list" ? "bg-muted" : ""}
            data-testid="button-view-list"
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
            data-testid="input-search-products"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]" data-testid="select-status-filter">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="archived">Archived</SelectItem>
          </SelectContent>
        </Select>
        <Select value={issueFilter} onValueChange={setIssueFilter}>
          <SelectTrigger className="w-[180px]" data-testid="select-issue-filter">
            <SelectValue placeholder="Issues" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Products</SelectItem>
            <SelectItem value="needs_description">Missing Description</SelectItem>
            <SelectItem value="needs_images">Missing Images</SelectItem>
            <SelectItem value="needs_tags">Missing Tags</SelectItem>
            <SelectItem value="optimized">Fully Optimized</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-36 w-full" />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-0">
              <div className="space-y-2 p-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            </CardContent>
          </Card>
        )
      ) : filteredProducts.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="p-4 rounded-full bg-muted mb-4">
                <Package className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">No Products Found</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                {search || statusFilter !== "all" || issueFilter !== "all"
                  ? "Try adjusting your filters to find products."
                  : "Sync your Shopify store to import products."}
              </p>
            </div>
          </CardContent>
        </Card>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProducts.map((product) => (
            <ProductGridCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Inventory</TableHead>
                  <TableHead>Issues</TableHead>
                  <TableHead>AI Score</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <ProductTableRow key={product.id} product={product} />
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>Showing {filteredProducts.length} of {products?.length || 0} products</span>
      </div>
    </div>
  );
}