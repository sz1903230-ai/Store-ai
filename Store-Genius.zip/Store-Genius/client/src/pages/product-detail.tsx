import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  Package,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  FileText,
  ImageIcon,
  Tag,
  ExternalLink,
  RefreshCw
} from "lucide-react";
import type { Product, Issue, Improvement } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function ImprovementComparison({ improvement }: { improvement: Improvement }) {
  const { toast } = useToast();

  const applyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/improvements/${improvement.id}/apply`);
    },
    onSuccess: () => {
      toast({ title: "Improvement applied", description: "Changes have been saved" });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  return (
    <div className="space-y-4 p-4 rounded-md border" data-testid={`comparison-${improvement.id}`}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="font-medium capitalize">{improvement.type} Improvement</span>
        </div>
        <Badge variant="outline">
          {Math.round((improvement.confidence || 0.8) * 100)}% confidence
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">Original</p>
          <div className="p-3 rounded-md bg-muted/50 min-h-[100px]">
            <p className="text-sm whitespace-pre-wrap">
              {improvement.originalContent || "No original content"}
            </p>
          </div>
        </div>
        <div className="space-y-2">
          <p className="text-sm font-medium text-green-600 dark:text-green-400">AI Improved</p>
          <div className="p-3 rounded-md bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 min-h-[100px]">
            <p className="text-sm whitespace-pre-wrap">{improvement.improvedContent}</p>
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        <Button 
          size="sm"
          onClick={() => applyMutation.mutate()}
          disabled={applyMutation.isPending}
          data-testid={`button-apply-${improvement.id}`}
        >
          <CheckCircle className="h-3 w-3 mr-1" />
          Apply This Change
        </Button>
      </div>
    </div>
  );
}

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();

  const { data: product, isLoading: productLoading } = useQuery<Product>({
    queryKey: ["/api/products", id],
  });

  const { data: issues } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: improvements } = useQuery<Improvement[]>({
    queryKey: ["/api/improvements"],
  });

  const productIssues = issues?.filter(i => i.productId === id && i.status === "open") || [];
  const productImprovements = improvements?.filter(i => i.productId === id && i.status === "pending") || [];

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${id}/analyze`);
    },
    onSuccess: () => {
      toast({ title: "Analysis started", description: "AI is analyzing this product" });
      queryClient.invalidateQueries({ queryKey: ["/api/products", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/improvements"] });
    },
  });

  const aiOptimizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/products/${id}/ai-optimize`);
    },
    onSuccess: (data: any) => {
      toast({ 
        title: "✨ AI Optimization Complete!", 
        description: `Generated ${data.badges?.length || 0} badges, ${data.bundle ? '1 bundle' : 'no bundles'}, and ${data.banner ? '1 banner' : 'no banners'}`
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Optimization failed", 
        description: error.message, 
        variant: "destructive" 
      });
    },
  });

  if (productLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="py-12 text-center">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-medium text-lg">Product Not Found</h3>
            <p className="text-sm text-muted-foreground mt-1">
              This product doesn't exist or has been removed.
            </p>
            <Link href="/products">
              <Button className="mt-4">Back to Products</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const hasIssues = !product.hasDescription || !product.hasImages || !product.hasTags;

  return (
    <div className="p-6 space-y-6" data-testid="page-product-detail">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Button 
            variant="default" 
            onClick={() => aiOptimizeMutation.mutate()}
            disabled={aiOptimizeMutation.isPending}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Sparkles className={`h-4 w-4 mr-2 ${aiOptimizeMutation.isPending ? "animate-spin" : ""}`} />
            {aiOptimizeMutation.isPending ? "AI Optimizing..." : "🚀 AI Optimize"}
          </Button>
          <Button 
            variant="outline" 
            onClick={() => analyzeMutation.mutate()}
            disabled={analyzeMutation.isPending}
          >
            <Sparkles className={`h-4 w-4 mr-2 ${analyzeMutation.isPending ? "animate-spin" : ""}`} />
            {analyzeMutation.isPending ? "Analyzing..." : "Analyze"}
          </Button>
          <Link href="/products">
            <Button variant="outline">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Products
            </Button>
          </Link>
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-semibold" data-testid="text-product-title">{product.title}</h1>
          <p className="text-muted-foreground font-mono text-sm mt-1">{product.shopifyId}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="aspect-square rounded-md bg-muted flex items-center justify-center overflow-hidden">
                {product.imageUrl ? (
                  <img 
                    src={product.imageUrl} 
                    alt={product.title} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Package className="h-16 w-16 text-muted-foreground" />
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Product Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline">{product.status}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price</span>
                <span className="font-medium">{product.price || "-"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Inventory</span>
                <span className="font-medium">{product.inventoryQuantity}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Vendor</span>
                <span className="font-medium">{product.vendor || "-"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Type</span>
                <span className="font-medium">{product.productType || "-"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">AI Score</span>
                <span className={`font-medium ${
                  (product.aiScore || 0) >= 80 ? "text-green-600" :
                  (product.aiScore || 0) >= 50 ? "text-yellow-600" :
                  "text-red-600"
                }`}>
                  {product.aiScore || 0}%
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Optimization Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Description</span>
                </div>
                {product.hasDescription ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                )}
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Images</span>
                </div>
                {product.hasImages ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                )}
              </div>
              <div className="flex items-center justify-between p-2 rounded-md bg-muted/50">
                <div className="flex items-center gap-2">
                  <Tag className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Tags</span>
                </div>
                {product.hasTags ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="improvements">
                AI Improvements ({productImprovements.length})
              </TabsTrigger>
              <TabsTrigger value="issues">
                Issues ({productIssues.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent>
                  {product.description ? (
                    <p className="text-sm whitespace-pre-wrap">{product.description}</p>
                  ) : (
                    <div className="flex flex-col items-center py-8 text-center">
                      <FileText className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">No description available</p>
                      <Button 
                        size="sm" 
                        className="mt-3"
                        onClick={() => analyzeMutation.mutate()}
                        disabled={analyzeMutation.isPending}
                      >
                        <Sparkles className="h-3 w-3 mr-1" />
                        Generate with AI
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tags</CardTitle>
                </CardHeader>
                <CardContent>
                  {product.tags && product.tags.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {product.tags.map((tag, idx) => (
                        <Badge key={idx} variant="secondary">{tag}</Badge>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center py-8 text-center">
                      <Tag className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">No tags available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="improvements" className="space-y-4">
              {productImprovements.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Sparkles className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="font-medium">No Pending Improvements</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Click "Analyze with AI" to generate improvement suggestions
                    </p>
                  </CardContent>
                </Card>
              ) : (
                productImprovements.map((improvement) => (
                  <ImprovementComparison key={improvement.id} improvement={improvement} />
                ))
              )}
            </TabsContent>

            <TabsContent value="issues" className="space-y-4">
              {productIssues.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center">
                    <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <p className="font-medium">No Issues Found</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      This product is in good shape!
                    </p>
                  </CardContent>
                </Card>
              ) : (
                productIssues.map((issue) => (
                  <Card key={issue.id} className="border-l-4 border-l-yellow-500">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5 text-yellow-600" />
                        <div>
                          <p className="font-medium">{issue.title}</p>
                          <p className="text-sm text-muted-foreground">{issue.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}