import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Gift,
  Package,
  Percent,
  CheckCircle,
  XCircle,
  Sparkles,
  ArrowRight
} from "lucide-react";
import { Link } from "wouter";
import type { BundleSuggestion, Product } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function BundleCard({ 
  bundle, 
  products 
}: { 
  bundle: BundleSuggestion; 
  products: Map<string, Product>;
}) {
  const { toast } = useToast();
  const mainProduct = bundle.productId ? products.get(bundle.productId) : undefined;
  const suggestedProducts = bundle.suggestedProductIds?.map(id => products.get(id)).filter(Boolean) || [];

  const applyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/bundles/${bundle.id}/apply`);
    },
    onSuccess: () => {
      toast({ title: "Bundle created", description: "Bundle has been added to your store" });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/bundles/${bundle.id}`, { status: "rejected" });
    },
    onSuccess: () => {
      toast({ title: "Bundle dismissed", description: "Suggestion has been removed" });
      queryClient.invalidateQueries({ queryKey: ["/api/bundles"] });
    },
  });

  return (
    <Card className="hover-elevate" data-testid={`card-bundle-${bundle.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-md bg-primary/10">
              <Gift className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-base">{bundle.bundleName || "Product Bundle"}</CardTitle>
              <CardDescription className="text-xs mt-0.5">
                {bundle.suggestedProductIds?.length || 0 + 1} products
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="gap-1 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
              <Percent className="h-3 w-3" />
              {bundle.discountPercentage || 10}% off
            </Badge>
            <Badge variant="outline">
              {Math.round((bundle.confidence || 0.7) * 100)}%
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {bundle.bundleDescription && (
          <p className="text-sm text-muted-foreground">{bundle.bundleDescription}</p>
        )}

        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Included Products:</p>
          <div className="space-y-2">
            {mainProduct && (
              <Link href={`/products/${mainProduct.id}`}>
                <div className="flex items-center gap-3 p-2 rounded-md bg-muted/50 hover:bg-muted cursor-pointer transition-colors">
                  <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                    {mainProduct.imageUrl ? (
                      <img src={mainProduct.imageUrl} alt={mainProduct.title} className="h-full w-full object-cover" />
                    ) : (
                      <Package className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{mainProduct.title}</p>
                    <p className="text-xs text-muted-foreground">{mainProduct.price}</p>
                  </div>
                  <Badge size="sm" variant="secondary">Main</Badge>
                </div>
              </Link>
            )}
            {suggestedProducts.map((product) => product && (
              <Link key={product.id} href={`/products/${product.id}`}>
                <div className="flex items-center gap-3 p-2 rounded-md bg-muted/50 hover:bg-muted cursor-pointer transition-colors">
                  <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.title} className="h-full w-full object-cover" />
                    ) : (
                      <Package className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{product.title}</p>
                    <p className="text-xs text-muted-foreground">{product.price}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="flex gap-2 pt-2">
          <Button 
            size="sm" 
            className="flex-1"
            onClick={() => applyMutation.mutate()}
            disabled={applyMutation.isPending}
            data-testid={`button-apply-bundle-${bundle.id}`}
          >
            <CheckCircle className="h-3 w-3 mr-1" />
            Create Bundle
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => rejectMutation.mutate()}
            disabled={rejectMutation.isPending}
            data-testid={`button-reject-bundle-${bundle.id}`}
          >
            <XCircle className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Bundles() {
  const { data: bundles, isLoading: bundlesLoading } = useQuery<BundleSuggestion[]>({
    queryKey: ["/api/bundles"],
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const productMap = new Map(products?.map(p => [p.id, p]) || []);
  const pendingBundles = bundles?.filter(b => b.status === "pending") || [];
  const appliedBundles = bundles?.filter(b => b.status === "applied") || [];

  return (
    <div className="p-6 space-y-6" data-testid="page-bundles">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-bundles-title">Bundle Suggestions</h1>
          <p className="text-muted-foreground mt-1">
            AI-recommended product bundles to increase average order value
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="gap-1">
            <Sparkles className="h-3 w-3" />
            {pendingBundles.length} suggestions
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Gift className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold">{pendingBundles.length}</p>
                <p className="text-xs text-muted-foreground">Pending Suggestions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-green-100 dark:bg-green-900/30">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold">{appliedBundles.length}</p>
                <p className="text-xs text-muted-foreground">Active Bundles</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {bundlesLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-64 w-full" />
          ))}
        </div>
      ) : pendingBundles.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="p-4 rounded-full bg-muted mb-4">
                <Gift className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">No Bundle Suggestions</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                AI will analyze your products and suggest bundles based on purchase patterns and product categories.
              </p>
              <Link href="/products">
                <Button className="mt-4" data-testid="button-view-products">
                  View Products
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {pendingBundles.map((bundle) => (
            <BundleCard key={bundle.id} bundle={bundle} products={productMap} />
          ))}
        </div>
      )}
    </div>
  );
}
