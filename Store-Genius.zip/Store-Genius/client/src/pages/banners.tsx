import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Megaphone,
  CheckCircle,
  XCircle,
  Sparkles,
  Copy,
  Package
} from "lucide-react";
import type { BannerRecommendation, Product } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const bannerStyles = {
  sale: {
    bg: "bg-gradient-to-r from-red-500 to-orange-500",
    label: "Sale",
  },
  new_arrival: {
    bg: "bg-gradient-to-r from-blue-500 to-cyan-500",
    label: "New Arrival",
  },
  limited: {
    bg: "bg-gradient-to-r from-purple-500 to-pink-500",
    label: "Limited Edition",
  },
  bestseller: {
    bg: "bg-gradient-to-r from-green-500 to-emerald-500",
    label: "Bestseller",
  },
};

function BannerPreviewCard({ 
  banner, 
  product 
}: { 
  banner: BannerRecommendation; 
  product?: Product;
}) {
  const { toast } = useToast();
  const style = bannerStyles[banner.bannerType as keyof typeof bannerStyles] || bannerStyles.sale;

  const applyMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/banners/${banner.id}/apply`);
    },
    onSuccess: () => {
      toast({ title: "Banner applied", description: "Banner has been added to your product" });
      queryClient.invalidateQueries({ queryKey: ["/api/banners"] });
    },
  });

  const copyToClipboard = () => {
    const text = `${banner.headline}${banner.subheadline ? `\n${banner.subheadline}` : ""}`;
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard", description: "Banner text has been copied" });
  };

  return (
    <Card className="hover-elevate overflow-hidden" data-testid={`card-banner-${banner.id}`}>
      <div className={`${style.bg} p-6 text-white text-center`}>
        <Badge className="mb-2 bg-white/20 text-white border-0">
          {style.label}
        </Badge>
        <h3 className="text-xl font-bold">{banner.headline}</h3>
        {banner.subheadline && (
          <p className="text-sm opacity-90 mt-1">{banner.subheadline}</p>
        )}
        {banner.ctaText && (
          <Button size="sm" variant="secondary" className="mt-3">
            {banner.ctaText}
          </Button>
        )}
      </div>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <Badge variant="outline">
            {Math.round((banner.confidence || 0.75) * 100)}% confidence
          </Badge>
          <Badge variant="secondary" className="capitalize">
            {banner.bannerType?.replace("_", " ")}
          </Badge>
        </div>

        {product && (
          <Link href={`/products/${product.id}`}>
            <div className="flex items-center gap-3 p-2 rounded-md bg-muted/50 hover:bg-muted cursor-pointer transition-colors">
              <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
                {product.imageUrl ? (
                  <img src={product.imageUrl} alt={product.title} className="h-full w-full object-cover" />
                ) : (
                  <Package className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{product.title}</p>
                <p className="text-xs text-muted-foreground">{product.price}</p>
              </div>
            </div>
          </Link>
        )}

        <div className="flex gap-2">
          <Button 
            size="sm" 
            className="flex-1"
            onClick={() => applyMutation.mutate()}
            disabled={applyMutation.isPending}
            data-testid={`button-apply-banner-${banner.id}`}
          >
            <CheckCircle className="h-3 w-3 mr-1" />
            Apply
          </Button>
          <Button 
            size="sm" 
            variant="outline"
            onClick={copyToClipboard}
            data-testid={`button-copy-banner-${banner.id}`}
          >
            <Copy className="h-3 w-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Banners() {
  const { data: banners, isLoading } = useQuery<BannerRecommendation[]>({
    queryKey: ["/api/banners"],
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const productMap = new Map(products?.map(p => [p.id, p]) || []);
  const pendingBanners = banners?.filter(b => b.status === "pending") || [];
  const appliedBanners = banners?.filter(b => b.status === "applied") || [];

  return (
    <div className="p-6 space-y-6" data-testid="page-banners">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-banners-title">Banner Recommendations</h1>
          <p className="text-muted-foreground mt-1">
            AI-generated promotional banners for your products
          </p>
        </div>
        <Badge variant="outline" className="gap-1">
          <Sparkles className="h-3 w-3" />
          {pendingBanners.length} suggestions
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Megaphone className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold">{pendingBanners.length}</p>
                <p className="text-xs text-muted-foreground">Ready to Apply</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-green-100 dark:bg-green-900/30">
                <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-semibold">{appliedBanners.length}</p>
                <p className="text-xs text-muted-foreground">Applied Banners</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-72 w-full" />
          ))}
        </div>
      ) : pendingBanners.length === 0 ? (
        <Card>
          <CardContent className="py-12">
            <div className="flex flex-col items-center justify-center text-center">
              <div className="p-4 rounded-full bg-muted mb-4">
                <Megaphone className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-medium text-lg">No Banner Suggestions</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                AI will generate promotional banner recommendations based on your products and their attributes.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {pendingBanners.map((banner) => (
            <BannerPreviewCard
              key={banner.id}
              banner={banner}
              product={banner.productId ? productMap.get(banner.productId) : undefined}
            />
          ))}
        </div>
      )}
    </div>
  );
}