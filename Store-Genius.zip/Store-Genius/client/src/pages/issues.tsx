import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertTriangle,
  CheckCircle,
  XCircle,
  Zap,
  Clock,
  FileText,
  Image as ImageIcon,
  Tag,
  Search as SearchIcon,
  Filter,
  ChevronRight
} from "lucide-react";
import { Link } from "wouter";
import type { Issue, Product } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const issueTypeIcons: Record<string, typeof AlertTriangle> = {
  missing_description: FileText,
  missing_images: ImageIcon,
  missing_tags: Tag,
  low_seo: SearchIcon,
  default: AlertTriangle,
};

const severityConfig = {
  critical: {
    color: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    border: "border-l-red-500",
  },
  high: {
    color: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
    border: "border-l-orange-500",
  },
  medium: {
    color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    border: "border-l-yellow-500",
  },
  low: {
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
    border: "border-l-blue-500",
  },
};

function IssueCard({ issue, product }: { issue: Issue; product?: Product }) {
  const { toast } = useToast();
  const Icon = issueTypeIcons[issue.type] || issueTypeIcons.default;
  const severity = severityConfig[issue.severity as keyof typeof severityConfig] || severityConfig.medium;

  const fixMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/issues/${issue.id}/fix`);
    },
    onSuccess: () => {
      toast({ title: "Issue fixed", description: "The issue has been resolved" });
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const ignoreMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("PATCH", `/api/issues/${issue.id}`, { status: "ignored" });
    },
    onSuccess: () => {
      toast({ title: "Issue ignored", description: "The issue has been marked as ignored" });
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
    },
  });

  return (
    <Card 
      className={`hover-elevate border-l-4 ${severity.border}`}
      data-testid={`card-issue-${issue.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <div className={`p-2 rounded-md ${
            issue.severity === "critical" || issue.severity === "high"
              ? "bg-destructive/10"
              : "bg-muted"
          }`}>
            <Icon className={`h-5 w-5 ${
              issue.severity === "critical" || issue.severity === "high"
                ? "text-destructive"
                : "text-muted-foreground"
            }`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-medium text-base">{issue.title}</h3>
              <Badge variant="secondary" className={severity.color}>
                {issue.severity}
              </Badge>
              {issue.autoFixable && (
                <Badge variant="outline" className="gap-1">
                  <Zap className="h-3 w-3" />
                  Auto-fixable
                </Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              {issue.description}
            </p>
            {product && (
              <Link href={`/products/${product.id}`}>
                <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground hover:text-foreground cursor-pointer">
                  <span className="truncate max-w-[200px]">{product.title}</span>
                  <ChevronRight className="h-3 w-3" />
                </div>
              </Link>
            )}
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {issue.autoFixable && (
              <Button 
                size="sm" 
                onClick={() => fixMutation.mutate()}
                disabled={fixMutation.isPending}
                data-testid={`button-fix-issue-${issue.id}`}
              >
                <Zap className="h-3 w-3 mr-1" />
                Fix Now
              </Button>
            )}
            <Button 
              size="sm" 
              variant="outline"
              onClick={() => ignoreMutation.mutate()}
              disabled={ignoreMutation.isPending}
              data-testid={`button-ignore-issue-${issue.id}`}
            >
              <XCircle className="h-3 w-3 mr-1" />
              Ignore
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function IssueSummaryCard({ 
  title, 
  count, 
  icon: Icon, 
  color 
}: { 
  title: string; 
  count: number; 
  icon: typeof AlertTriangle; 
  color: string;
}) {
  return (
    <Card data-testid={`card-summary-${title.toLowerCase().replace(" ", "-")}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-md ${color}`}>
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <p className="text-2xl font-semibold">{count}</p>
            <p className="text-xs text-muted-foreground">{title}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Issues() {
  const [statusFilter, setStatusFilter] = useState<string>("open");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");

  const { data: issues, isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const productMap = new Map(products?.map(p => [p.id, p]) || []);

  const filteredIssues = issues?.filter((issue) => {
    const matchesStatus = statusFilter === "all" || issue.status === statusFilter;
    const matchesSeverity = severityFilter === "all" || issue.severity === severityFilter;
    const matchesType = typeFilter === "all" || issue.type === typeFilter;
    return matchesStatus && matchesSeverity && matchesType;
  }) || [];

  const criticalCount = issues?.filter(i => i.severity === "critical" && i.status === "open").length || 0;
  const highCount = issues?.filter(i => i.severity === "high" && i.status === "open").length || 0;
  const autoFixableCount = issues?.filter(i => i.autoFixable && i.status === "open").length || 0;
  const resolvedCount = issues?.filter(i => i.status === "resolved").length || 0;

  return (
    <div className="p-6 space-y-6" data-testid="page-issues">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-issues-title">Issues</h1>
          <p className="text-muted-foreground mt-1">
            Problems detected in your store that need attention
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <IssueSummaryCard
          title="Critical Issues"
          count={criticalCount}
          icon={AlertTriangle}
          color="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
        />
        <IssueSummaryCard
          title="High Priority"
          count={highCount}
          icon={AlertTriangle}
          color="bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400"
        />
        <IssueSummaryCard
          title="Auto-fixable"
          count={autoFixableCount}
          icon={Zap}
          color="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400"
        />
        <IssueSummaryCard
          title="Resolved"
          count={resolvedCount}
          icon={CheckCircle}
          color="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
        />
      </div>

      <div className="flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Filters:</span>
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[130px]" data-testid="select-status-filter">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="ignored">Ignored</SelectItem>
          </SelectContent>
        </Select>
        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-[130px]" data-testid="select-severity-filter">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severity</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="low">Low</SelectItem>
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[160px]" data-testid="select-type-filter">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="missing_description">Missing Description</SelectItem>
            <SelectItem value="missing_images">Missing Images</SelectItem>
            <SelectItem value="missing_tags">Missing Tags</SelectItem>
            <SelectItem value="low_seo">Low SEO</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        {issuesLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))
        ) : filteredIssues.length === 0 ? (
          <Card>
            <CardContent className="py-12">
              <div className="flex flex-col items-center justify-center text-center">
                <div className="p-4 rounded-full bg-green-100 dark:bg-green-900/30 mb-4">
                  <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="font-medium text-lg">No Issues Found</h3>
                <p className="text-sm text-muted-foreground mt-1 max-w-sm">
                  {statusFilter !== "all" || severityFilter !== "all" || typeFilter !== "all"
                    ? "Try adjusting your filters to see more issues."
                    : "Your store is in great shape! No issues detected."}
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredIssues.map((issue) => (
            <IssueCard
              key={issue.id}
              issue={issue}
              product={issue.productId ? productMap.get(issue.productId) : undefined}
            />
          ))
        )}
      </div>

      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>Showing {filteredIssues.length} of {issues?.length || 0} issues</span>
      </div>
    </div>
  );
}
