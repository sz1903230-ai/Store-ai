import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  TrendingUp,
  TrendingDown,
  Activity,
  Package,
  CheckCircle,
  AlertTriangle,
  Sparkles
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from "recharts";
import type { Store, Product, Issue, Improvement } from "@shared/schema";

const COLORS = ["hsl(217, 91%, 60%)", "hsl(173, 80%, 40%)", "hsl(43, 90%, 55%)", "hsl(0, 84%, 60%)"];

function StatCard({
  title,
  value,
  change,
  changeLabel,
  icon: Icon,
  trend,
}: {
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  icon: typeof Activity;
  trend?: "up" | "down" | "neutral";
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="p-2 rounded-md bg-muted">
            <Icon className="h-4 w-4 text-muted-foreground" />
          </div>
          {change !== undefined && (
            <div className={`flex items-center gap-1 text-xs ${
              trend === "up" ? "text-green-600 dark:text-green-400" :
              trend === "down" ? "text-red-600 dark:text-red-400" :
              "text-muted-foreground"
            }`}>
              {trend === "up" ? <TrendingUp className="h-3 w-3" /> : 
               trend === "down" ? <TrendingDown className="h-3 w-3" /> : null}
              {change > 0 ? "+" : ""}{change}%
            </div>
          )}
        </div>
        <div className="mt-3">
          <p className="text-2xl font-semibold">{value}</p>
          <p className="text-xs text-muted-foreground">{title}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Analytics() {
  const { data: stores, isLoading: storesLoading } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: issues, isLoading: issuesLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const { data: improvements, isLoading: improvementsLoading } = useQuery<Improvement[]>({
    queryKey: ["/api/improvements"],
  });

  const isLoading = storesLoading || productsLoading || issuesLoading || improvementsLoading;

  const store = stores?.[0];
  const totalProducts = products?.length || 0;
  const optimizedProducts = products?.filter(p => p.hasDescription && p.hasImages && p.hasTags).length || 0;
  const openIssues = issues?.filter(i => i.status === "open").length || 0;
  const resolvedIssues = issues?.filter(i => i.status === "resolved").length || 0;
  const appliedImprovements = improvements?.filter(i => i.status === "applied").length || 0;

  const optimizationRate = totalProducts > 0 ? Math.round((optimizedProducts / totalProducts) * 100) : 0;

  const issuesByType = [
    { name: "Missing Description", value: products?.filter(p => !p.hasDescription).length || 0 },
    { name: "Missing Images", value: products?.filter(p => !p.hasImages).length || 0 },
    { name: "Missing Tags", value: products?.filter(p => !p.hasTags).length || 0 },
    { name: "Low SEO", value: products?.filter(p => (p.seoScore || 0) < 50).length || 0 },
  ].filter(item => item.value > 0);

  const mockHealthTrend = [
    { date: "Mon", score: 65 },
    { date: "Tue", score: 68 },
    { date: "Wed", score: 72 },
    { date: "Thu", score: 70 },
    { date: "Fri", score: 75 },
    { date: "Sat", score: 78 },
    { date: "Sun", score: store?.healthScore || 80 },
  ];

  const mockImprovementsTrend = [
    { date: "Week 1", applied: 5, pending: 12 },
    { date: "Week 2", applied: 8, pending: 10 },
    { date: "Week 3", applied: 12, pending: 8 },
    { date: "Week 4", applied: appliedImprovements, pending: improvements?.filter(i => i.status === "pending").length || 0 },
  ];

  return (
    <div className="p-6 space-y-6" data-testid="page-analytics">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-semibold" data-testid="text-analytics-title">Analytics</h1>
          <p className="text-muted-foreground mt-1">
            Track your store's optimization progress and AI performance
          </p>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Store Health Score"
            value={`${store?.healthScore || 0}%`}
            change={5}
            icon={Activity}
            trend="up"
          />
          <StatCard
            title="Products Optimized"
            value={`${optimizedProducts}/${totalProducts}`}
            change={optimizationRate}
            icon={Package}
            trend={optimizationRate >= 50 ? "up" : "down"}
          />
          <StatCard
            title="Issues Resolved"
            value={resolvedIssues}
            change={resolvedIssues > 0 ? 15 : 0}
            icon={CheckCircle}
            trend="up"
          />
          <StatCard
            title="AI Improvements Applied"
            value={appliedImprovements}
            icon={Sparkles}
            trend="up"
          />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Health Score Trend</CardTitle>
            <CardDescription>Store optimization progress over time</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={mockHealthTrend}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" />
                  <YAxis domain={[0, 100]} className="text-xs" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)"
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="score" 
                    stroke="hsl(217, 91%, 60%)" 
                    fill="hsl(217, 91%, 60%)" 
                    fillOpacity={0.2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Issues by Type</CardTitle>
            <CardDescription>Breakdown of detected problems</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : issuesByType.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mb-3" />
                <p className="font-medium">No Issues Found</p>
                <p className="text-sm text-muted-foreground">Your store is fully optimized!</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={issuesByType}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}`}
                  >
                    {issuesByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)"
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">AI Improvements Over Time</CardTitle>
          <CardDescription>Applied vs pending improvements weekly</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={mockImprovementsTrend}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)"
                  }}
                />
                <Bar dataKey="applied" fill="hsl(173, 80%, 40%)" name="Applied" radius={[4, 4, 0, 0]} />
                <Bar dataKey="pending" fill="hsl(217, 91%, 60%)" name="Pending" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
