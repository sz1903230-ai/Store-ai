import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Store,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Link as LinkIcon,
  Trash2,
  Settings as SettingsIcon,
  Sparkles,
  Bell
} from "lucide-react";
import type { Store as StoreType } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();
  const [shopDomain, setShopDomain] = useState("");
  const [accessToken, setAccessToken] = useState("");

  const { data: stores, isLoading } = useQuery<StoreType[]>({
    queryKey: ["/api/stores"],
  });

  const activeStore = stores?.[0];

  const connectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/stores/connect", {
        shopDomain: shopDomain.includes(".myshopify.com") ? shopDomain : `${shopDomain}.myshopify.com`,
        accessToken,
      });
    },
    onSuccess: () => {
      toast({ title: "Store connected", description: "Your Shopify store has been connected successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      setShopDomain("");
      setAccessToken("");
    },
    onError: (error: Error) => {
      toast({ title: "Connection failed", description: error.message, variant: "destructive" });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", `/api/stores/${activeStore?.id}/sync`);
    },
    onSuccess: () => {
      toast({ title: "Sync started", description: "Your store data is being synced" });
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    },
  });

  const disconnectMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/stores/${activeStore?.id}`);
    },
    onSuccess: () => {
      toast({ title: "Store disconnected", description: "Your store has been disconnected" });
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
    },
  });

  return (
    <div className="p-6 space-y-6" data-testid="page-settings">
      <div>
        <h1 className="text-3xl font-semibold" data-testid="text-settings-title">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Manage your Shopify store connection and AI preferences
        </p>
      </div>

      <div className="grid gap-6 max-w-2xl">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Store className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Shopify Store</CardTitle>
                <CardDescription>Connect and manage your Shopify store</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeStore ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-md bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-full bg-green-100 dark:bg-green-900/30">
                      <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <p className="font-medium">{activeStore.shopName}</p>
                      <p className="text-sm text-muted-foreground">{activeStore.shopDomain}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                    Connected
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Products</p>
                    <p className="font-medium">{activeStore.totalProducts}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Health Score</p>
                    <p className="font-medium">{activeStore.healthScore}%</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Active Issues</p>
                    <p className="font-medium">{activeStore.activeIssues}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Last Sync</p>
                    <p className="font-medium">
                      {activeStore.lastSyncAt 
                        ? new Date(activeStore.lastSyncAt).toLocaleString() 
                        : "Never"}
                    </p>
                  </div>
                </div>

                <Separator />

                <div className="flex gap-2">
                  <Button 
                    onClick={() => syncMutation.mutate()}
                    disabled={syncMutation.isPending}
                    data-testid="button-sync-store"
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? "animate-spin" : ""}`} />
                    Sync Now
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={() => disconnectMutation.mutate()}
                    disabled={disconnectMutation.isPending}
                    data-testid="button-disconnect-store"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Disconnect
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-2 p-3 rounded-md bg-muted/50 text-sm">
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">No store connected. Enter your Shopify credentials below.</span>
                </div>

                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="shopDomain">Shop Domain</Label>
                    <Input
                      id="shopDomain"
                      placeholder="your-store.myshopify.com"
                      value={shopDomain}
                      onChange={(e) => setShopDomain(e.target.value)}
                      data-testid="input-shop-domain"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accessToken">Admin API Access Token</Label>
                    <Input
                      id="accessToken"
                      type="password"
                      placeholder="shpat_..."
                      value={accessToken}
                      onChange={(e) => setAccessToken(e.target.value)}
                      data-testid="input-access-token"
                    />
                    <p className="text-xs text-muted-foreground">
                      Create an access token in your Shopify Admin under Apps → Develop apps
                    </p>
                  </div>
                </div>

                <Button 
                  onClick={() => connectMutation.mutate()}
                  disabled={!shopDomain || !accessToken || connectMutation.isPending}
                  data-testid="button-connect-store"
                >
                  <LinkIcon className="h-4 w-4 mr-2" />
                  Connect Store
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>AI Settings</CardTitle>
                <CardDescription>Configure AI behavior and automation</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-generate descriptions</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically generate product descriptions for new products
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-auto-descriptions" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Auto-detect issues</Label>
                <p className="text-sm text-muted-foreground">
                  Continuously scan for product page issues
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-auto-issues" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Generate bundle suggestions</Label>
                <p className="text-sm text-muted-foreground">
                  AI will suggest product bundles based on categories
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-bundle-suggestions" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Banner recommendations</Label>
                <p className="text-sm text-muted-foreground">
                  Generate promotional banner ideas for products
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-banner-recommendations" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-primary/10">
                <Bell className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Configure alert preferences</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Critical issue alerts</Label>
                <p className="text-sm text-muted-foreground">
                  Get notified when critical issues are detected
                </p>
              </div>
              <Switch defaultChecked data-testid="switch-critical-alerts" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Weekly summary</Label>
                <p className="text-sm text-muted-foreground">
                  Receive a weekly email summary of store health
                </p>
              </div>
              <Switch data-testid="switch-weekly-summary" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
