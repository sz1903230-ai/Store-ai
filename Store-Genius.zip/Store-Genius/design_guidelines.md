# Design Guidelines: AI-Powered Shopify Store Manager

## Design Approach

**System:** Shopify Polaris-inspired with Linear-style refinement for a professional SaaS dashboard
**Rationale:** As a productivity tool for store management, clarity and efficiency take priority over visual flair. Drawing from Shopify Polaris ensures familiarity for Shopify merchants, while Linear's precision enhances the modern feel.

## Typography

**Font Families:**
- Primary: Inter (via Google Fonts CDN) - all UI text, labels, body copy
- Monospace: JetBrains Mono - for product IDs, SKUs, technical data

**Hierarchy:**
- Dashboard Headlines: text-3xl font-semibold
- Section Headers: text-xl font-semibold
- Card Titles: text-base font-medium
- Body Text: text-sm font-normal
- Captions/Metadata: text-xs text-gray-600

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, and 16 consistently
- Component padding: p-4 or p-6
- Section spacing: gap-6 or gap-8
- Page margins: p-6 to p-8
- Card spacing: p-4

**Grid Structure:**
- Sidebar: Fixed 256px (w-64) on desktop, collapsible on mobile
- Main content: max-w-7xl with px-6
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 with gap-6

## Component Library

### Navigation
- **Sidebar Navigation:** Fixed left sidebar with icon + label items, active state highlighting, collapsible sections for Dashboard, Products, Issues, AI Insights, Settings
- **Top Bar:** Breadcrumb navigation, store selector dropdown, notification bell (Heroicons), user profile menu

### Dashboard Components
- **Metric Cards:** Grid layout showing Store Health Score, Active Issues, AI Suggestions, Recent Actions - each card with large number, trend indicator (up/down arrow), and small description
- **Issue Alert Cards:** Warning/error states with icon, title, description, and "Fix Now" action button - prioritized by severity
- **AI Recommendation Panels:** Distinctive cards with sparkle icon (Heroicons), recommendation title, before/after preview, and "Apply" or "Review" buttons

### Product Management
- **Product Grid/List Toggle:** Switch between card grid view and dense table view
- **Product Cards:** Thumbnail image (square, 80x80px), title, SKU, status badge, quick action menu (three dots)
- **Product Detail Panel:** Slide-out panel from right showing current state vs. AI-recommended improvements side-by-side

### Forms & Inputs
- **Form Groups:** Consistent label-above-input pattern with text-sm font-medium labels
- **Input Fields:** Rounded borders (rounded-md), focus states with ring, adequate height (h-10)
- **Action Buttons:** Primary (solid), Secondary (outline), Destructive (red accent for critical actions)
- **Toggle Switches:** For enable/disable AI features

### Data Display
- **Tables:** Sticky headers, alternating row backgrounds, sortable columns, row actions on hover
- **Status Badges:** Rounded-full pills for product status, issue severity, AI processing state
- **Progress Indicators:** For AI processing tasks, batch operations

### AI-Specific Components
- **AI Processing Indicator:** Animated shimmer effect on cards being analyzed
- **Comparison View:** Split-screen showing current vs. AI-improved version with highlighted changes
- **Confidence Meter:** Visual indicator (0-100%) for AI suggestion confidence

### Overlays
- **Confirmation Modals:** Center-screen for destructive actions (applying changes, deleting)
- **Notification Toasts:** Top-right corner for success/error feedback (4-second auto-dismiss)

## Images

**Dashboard Hero:** No hero image - this is a functional dashboard, lead with metrics immediately

**Product Thumbnails:** Square aspect ratio (1:1), displayed throughout product grids and lists at 80x80px or 120x120px depending on view density

**Before/After Comparisons:** When showing AI improvements, display side-by-side product image comparisons at 300x300px in the recommendation panels

**Empty States:** Custom illustrations (use placeholder comments for now) for "No issues found", "No products to optimize", etc.

## Animations

**Minimal Approach:**
- Smooth transitions on panel slides (slide-out product detail)
- Subtle hover states on interactive elements
- Loading skeleton screens for data fetching
- NO scroll animations or distracting effects

## Accessibility

- Maintain WCAG AA contrast ratios throughout
- Keyboard navigation for all interactive elements
- Focus indicators on all inputs and buttons
- ARIA labels for icon-only buttons
- Screen reader announcements for AI processing status changes