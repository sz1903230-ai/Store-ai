import {
  type User, type InsertUser,
  type Store, type InsertStore,
  type Product, type InsertProduct,
  type Issue, type InsertIssue,
  type Improvement, type InsertImprovement,
  type BundleSuggestion, type InsertBundleSuggestion,
  type BannerRecommendation, type InsertBannerRecommendation,
  users, stores, products, issues, improvements, bundleSuggestions, bannerRecommendations
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export type StoreUpdate = Partial<InsertStore> & {
  lastSyncAt?: Date | null;
  healthScore?: number;
  totalProducts?: number;
  activeIssues?: number;
};

export type ProductUpdate = Partial<InsertProduct> & {
  seoScore?: number;
  aiScore?: number;
  lastAnalyzedAt?: Date | null;
  updatedAt?: Date;
};

export type IssueUpdate = Partial<InsertIssue> & {
  resolvedAt?: Date | null;
};

export type ImprovementUpdate = Partial<InsertImprovement> & {
  appliedAt?: Date | null;
};

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getStore(id: string): Promise<Store | undefined>;
  getStores(): Promise<Store[]>;
  createStore(store: InsertStore): Promise<Store>;
  updateStore(id: string, store: StoreUpdate): Promise<Store | undefined>;
  deleteStore(id: string): Promise<boolean>;
  getProduct(id: string): Promise<Product | undefined>;
  getProducts(): Promise<Product[]>;
  getProductsByStore(storeId: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: ProductUpdate): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  getIssue(id: string): Promise<Issue | undefined>;
  getIssues(): Promise<Issue[]>;
  getIssuesByStore(storeId: string): Promise<Issue[]>;
  getIssuesByProduct(productId: string): Promise<Issue[]>;
  createIssue(issue: InsertIssue): Promise<Issue>;
  updateIssue(id: string, issue: IssueUpdate): Promise<Issue | undefined>;
  deleteIssue(id: string): Promise<boolean>;
  getImprovement(id: string): Promise<Improvement | undefined>;
  getImprovements(): Promise<Improvement[]>;
  getImprovementsByStore(storeId: string): Promise<Improvement[]>;
  getImprovementsByProduct(productId: string): Promise<Improvement[]>;
  createImprovement(improvement: InsertImprovement): Promise<Improvement>;
  updateImprovement(id: string, improvement: ImprovementUpdate): Promise<Improvement | undefined>;
  getBundleSuggestions(): Promise<BundleSuggestion[]>;
  getBundleSuggestionsByStore(storeId: string): Promise<BundleSuggestion[]>;
  createBundleSuggestion(suggestion: InsertBundleSuggestion): Promise<BundleSuggestion>;
  updateBundleSuggestion(id: string, suggestion: Partial<InsertBundleSuggestion>): Promise<BundleSuggestion | undefined>;
  getBannerRecommendations(): Promise<BannerRecommendation[]>;
  getBannerRecommendationsByStore(storeId: string): Promise<BannerRecommendation[]>;
  createBannerRecommendation(recommendation: InsertBannerRecommendation): Promise<BannerRecommendation>;
  updateBannerRecommendation(id: string, recommendation: Partial<InsertBannerRecommendation>): Promise<BannerRecommendation | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async getStore(id: string): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.id, id));
    return store;
  }

  async getStores(): Promise<Store[]> {
    return db.select().from(stores).orderBy(desc(stores.createdAt));
  }

  async createStore(store: InsertStore): Promise<Store> {
    const [created] = await db.insert(stores).values(store).returning();
    return created;
  }

  async updateStore(id: string, store: StoreUpdate): Promise<Store | undefined> {
    const [updated] = await db.update(stores).set(store as any).where(eq(stores.id, id)).returning();
    return updated;
  }

  async deleteStore(id: string): Promise<boolean> {
    await db.delete(stores).where(eq(stores.id, id));
    return true;
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getProducts(): Promise<Product[]> {
    return db.select().from(products).orderBy(desc(products.createdAt));
  }

  async getProductsByStore(storeId: string): Promise<Product[]> {
    return db.select().from(products).where(eq(products.storeId, storeId)).orderBy(desc(products.createdAt));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: string, product: ProductUpdate): Promise<Product | undefined> {
    const updateData = { ...product, updatedAt: new Date() };
    const [updated] = await db.update(products).set(updateData as any).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    await db.delete(products).where(eq(products.id, id));
    return true;
  }

  async getIssue(id: string): Promise<Issue | undefined> {
    const [issue] = await db.select().from(issues).where(eq(issues.id, id));
    return issue;
  }

  async getIssues(): Promise<Issue[]> {
    return db.select().from(issues).orderBy(desc(issues.createdAt));
  }

  async getIssuesByStore(storeId: string): Promise<Issue[]> {
    return db.select().from(issues).where(eq(issues.storeId, storeId)).orderBy(desc(issues.createdAt));
  }

  async getIssuesByProduct(productId: string): Promise<Issue[]> {
    return db.select().from(issues).where(eq(issues.productId, productId)).orderBy(desc(issues.createdAt));
  }

  async createIssue(issue: InsertIssue): Promise<Issue> {
    const [created] = await db.insert(issues).values(issue).returning();
    return created;
  }

  async updateIssue(id: string, issue: IssueUpdate): Promise<Issue | undefined> {
    const [updated] = await db.update(issues).set(issue as any).where(eq(issues.id, id)).returning();
    return updated;
  }

  async deleteIssue(id: string): Promise<boolean> {
    await db.delete(issues).where(eq(issues.id, id));
    return true;
  }

  async getImprovement(id: string): Promise<Improvement | undefined> {
    const [improvement] = await db.select().from(improvements).where(eq(improvements.id, id));
    return improvement;
  }

  async getImprovements(): Promise<Improvement[]> {
    return db.select().from(improvements).orderBy(desc(improvements.createdAt));
  }

  async getImprovementsByStore(storeId: string): Promise<Improvement[]> {
    return db.select().from(improvements).where(eq(improvements.storeId, storeId)).orderBy(desc(improvements.createdAt));
  }

  async getImprovementsByProduct(productId: string): Promise<Improvement[]> {
    return db.select().from(improvements).where(eq(improvements.productId, productId)).orderBy(desc(improvements.createdAt));
  }

  async createImprovement(improvement: InsertImprovement): Promise<Improvement> {
    const [created] = await db.insert(improvements).values(improvement).returning();
    return created;
  }

  async updateImprovement(id: string, improvement: ImprovementUpdate): Promise<Improvement | undefined> {
    const [updated] = await db.update(improvements).set(improvement as any).where(eq(improvements.id, id)).returning();
    return updated;
  }

  async getBundleSuggestions(): Promise<BundleSuggestion[]> {
    return db.select().from(bundleSuggestions).orderBy(desc(bundleSuggestions.createdAt));
  }

  async getBundleSuggestionsByStore(storeId: string): Promise<BundleSuggestion[]> {
    return db.select().from(bundleSuggestions).where(eq(bundleSuggestions.storeId, storeId)).orderBy(desc(bundleSuggestions.createdAt));
  }

  async createBundleSuggestion(suggestion: InsertBundleSuggestion): Promise<BundleSuggestion> {
    const [created] = await db.insert(bundleSuggestions).values(suggestion).returning();
    return created;
  }

  async updateBundleSuggestion(id: string, suggestion: Partial<InsertBundleSuggestion>): Promise<BundleSuggestion | undefined> {
    const [updated] = await db.update(bundleSuggestions).set(suggestion).where(eq(bundleSuggestions.id, id)).returning();
    return updated;
  }

  async getBannerRecommendations(): Promise<BannerRecommendation[]> {
    return db.select().from(bannerRecommendations).orderBy(desc(bannerRecommendations.createdAt));
  }

  async getBannerRecommendationsByStore(storeId: string): Promise<BannerRecommendation[]> {
    return db.select().from(bannerRecommendations).where(eq(bannerRecommendations.storeId, storeId)).orderBy(desc(bannerRecommendations.createdAt));
  }

  async createBannerRecommendation(recommendation: InsertBannerRecommendation): Promise<BannerRecommendation> {
    const [created] = await db.insert(bannerRecommendations).values(recommendation).returning();
    return created;
  }

  async updateBannerRecommendation(id: string, recommendation: Partial<InsertBannerRecommendation>): Promise<BannerRecommendation | undefined> {
    const [updated] = await db.update(bannerRecommendations).set(recommendation).where(eq(bannerRecommendations.id, id)).returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
