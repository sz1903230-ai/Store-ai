import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertStoreSchema, 
  insertProductSchema, 
  insertIssueSchema, 
  insertImprovementSchema 
} from "@shared/schema";
import { 
  analyzeProduct, 
  generateDescription, 
  generateTags, 
  generateBundleSuggestion, 
  generateBannerRecommendation,
  generateBadges,
  fixIssue
} from "./openai";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ============ STORES ============
  
  // Get all stores
  app.get("/api/stores", async (req, res) => {
    try {
      const stores = await storage.getStores();
      res.json(stores);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stores" });
    }
  });

  // Get single store
  app.get("/api/stores/:id", async (req, res) => {
    try {
      const store = await storage.getStore(req.params.id);
      if (!store) {
        return res.status(404).json({ error: "Store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch store" });
    }
  });

  // Connect store (replaces create store)
  app.post("/api/stores/connect", async (req, res) => {
    try {
      const { shopDomain, accessToken } = req.body;
      
      if (!shopDomain || !accessToken) {
        return res.status(400).json({ error: "Shop domain and access token are required" });
      }

      // Import ShopifyClient
      const { ShopifyClient } = await import("./shopify");
      const shopify = new ShopifyClient(shopDomain, accessToken);

      // Test connection
      const isConnected = await shopify.testConnection();
      if (!isConnected) {
        return res.status(401).json({ error: "Invalid credentials or unable to connect to Shopify" });
      }

      // Get shop info
      const shopInfo = await shopify.getShopInfo();
      if (!shopInfo) {
        return res.status(500).json({ error: "Failed to fetch store information" });
      }

      // Check if store already exists
      const existingStores = await storage.getStores();
      let store;
      
      if (existingStores.length > 0) {
        // Update existing store
        store = await storage.updateStore(existingStores[0].id, {
          shopDomain,
          shopName: shopInfo.name,
          accessToken,
          lastSyncAt: new Date(),
        });
      } else {
        // Create new store
        store = await storage.createStore({
          shopDomain,
          shopName: shopInfo.name,
          accessToken,
        });
      }

      res.json(store);
    } catch (error) {
      console.error("Store connection error:", error);
      res.status(500).json({ error: "Failed to connect store" });
    }
  });

  // Update store
  app.patch("/api/stores/:id", async (req, res) => {
    try {
      const store = await storage.updateStore(req.params.id, req.body);
      if (!store) {
        return res.status(404).json({ error: "Store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(500).json({ error: "Failed to update store" });
    }
  });

  // Delete store
  app.delete("/api/stores/:id", async (req, res) => {
    try {
      await storage.deleteStore(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete store" });
    }
  });

  // Sync store - fetches real products from Shopify
  app.post("/api/stores/:id/sync", async (req, res) => {
    try {
      const store = await storage.getStore(req.params.id);
      if (!store) {
        return res.status(404).json({ error: "Store not found" });
      }

      if (!store.accessToken) {
        return res.status(400).json({ error: "Store credentials not configured" });
      }

      // Import ShopifyClient
      const { ShopifyClient } = await import("./shopify");
      const shopify = new ShopifyClient(store.shopDomain, store.accessToken);

      // Fetch products from Shopify
      const shopifyProducts = await shopify.getProducts();
      
      if (shopifyProducts.length === 0) {
        return res.status(400).json({ error: "No products found in your Shopify store" });
      }

      const createdProducts = [];
      
      for (const shopifyProduct of shopifyProducts) {
        const productData = shopify.convertToLocalProduct(shopifyProduct, store.id);
        
        // Check if product already exists
        const existingProducts = await storage.getProductsByStore(store.id);
        const existingProduct = existingProducts.find(p => p.shopifyId === productData.shopifyId);
        
        let product;
        if (existingProduct) {
          product = await storage.updateProduct(existingProduct.id, productData);
        } else {
          product = await storage.createProduct(productData);
        }
        
        createdProducts.push(product);

        // Delete old open issues for this product to avoid duplicates during sync
        const existingProductIssues = await storage.getIssuesByProduct(product.id);
        for (const oldIssue of existingProductIssues) {
          if (oldIssue.status === "open") {
            await storage.deleteIssue(oldIssue.id);
          }
        }

        // Auto-detect issues
        if (!productData.hasDescription || !product.description || product.description.trim() === "") {
          await storage.createIssue({
            storeId: store.id,
            productId: product.id,
            type: "missing_description",
            severity: "high",
            title: "Missing Product Description",
            description: `Product "${product.title}" has no description. This hurts SEO and conversions.`,
            autoFixable: true,
          });
        }
        if (!productData.hasImages || !product.imageUrl) {
          await storage.createIssue({
            storeId: store.id,
            productId: product.id,
            type: "missing_images",
            severity: "critical",
            title: "No Product Images",
            description: `Product "${product.title}" has no images. Products without images have significantly lower conversion rates.`,
            autoFixable: false,
          });
        }
        if (!productData.hasTags || !productData.tags || productData.tags.length === 0) {
          await storage.createIssue({
            storeId: store.id,
            productId: product.id,
            type: "missing_tags",
            severity: "medium",
            title: "Missing Tags",
            description: `Product "${product.title}" has no tags. Tags help with search and discovery.`,
            autoFixable: true,
          });
        }
      }

      // Update store stats
      const allProducts = await storage.getProductsByStore(store.id);
      const allIssues = await storage.getIssuesByStore(store.id);
      const openIssues = allIssues.filter(i => i.status === "open");
      
      const healthScore = Math.max(0, 100 - (openIssues.length * 10));
      
      await storage.updateStore(store.id, {
        totalProducts: allProducts.length,
        activeIssues: openIssues.length,
        healthScore,
        lastSyncAt: new Date(),
      });

      res.json({ 
        message: "Store synced successfully from Shopify",
        productsCreated: createdProducts.length,
        issuesDetected: openIssues.length
      });
    } catch (error) {
      console.error("Sync error:", error);
      res.status(500).json({ error: "Failed to sync store" });
    }
  });

  // ============ PRODUCTS ============
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      const products = storeId 
        ? await storage.getProductsByStore(storeId)
        : await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Update product
  app.patch("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.updateProduct(req.params.id, req.body);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  // Analyze product with AI
  app.post("/api/products/:id/analyze", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const analysis = await analyzeProduct(product);
      
      // Update product scores
      await storage.updateProduct(product.id, {
        seoScore: analysis.seoScore,
        aiScore: analysis.aiScore,
        lastAnalyzedAt: new Date(),
      });

      // Delete old open issues for this product to avoid duplicates
      const existingIssues = await storage.getIssuesByProduct(product.id);
      for (const oldIssue of existingIssues) {
        if (oldIssue.status === "open") {
          await storage.deleteIssue(oldIssue.id);
        }
      }

      // Create issues from analysis
      for (const issue of analysis.issues) {
        await storage.createIssue({
          storeId: product.storeId,
          productId: product.id,
          type: issue.type,
          severity: issue.severity,
          title: issue.title,
          description: issue.description,
          autoFixable: issue.autoFixable,
        });
      }

      // Update store stats
      const allIssues = await storage.getIssuesByStore(product.storeId);
      const openIssues = allIssues.filter(i => i.status === "open");
      const allProducts = await storage.getProductsByStore(product.storeId);
      const healthScore = Math.max(0, 100 - (openIssues.length * 10));
      
      await storage.updateStore(product.storeId, {
        activeIssues: openIssues.length,
        healthScore,
      });

      res.json(analysis);
    } catch (error) {
      console.error("Analysis error:", error);
      res.status(500).json({ error: "Failed to analyze product" });
    }
  });

  // Generate improved description
  app.post("/api/products/:id/generate-description", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const result = await generateDescription(product);
      
      // Store as pending improvement
      const improvement = await storage.createImprovement({
        storeId: product.storeId,
        productId: product.id,
        type: "description",
        originalContent: product.description || "",
        improvedContent: result.improvedDescription,
        confidence: result.confidence,
      });

      res.json({ improvement, highlights: result.highlights });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate description" });
    }
  });

  // Generate improved tags
  app.post("/api/products/:id/generate-tags", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const result = await generateTags(product);
      
      const improvement = await storage.createImprovement({
        storeId: product.storeId,
        productId: product.id,
        type: "tags",
        originalContent: product.tags?.join(", ") || "",
        improvedContent: result.tags.join(", "),
        confidence: result.confidence,
      });

      res.json({ improvement, tags: result.tags });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate tags" });
    }
  });

  // Generate bundle suggestion
  app.post("/api/products/:id/generate-bundle", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const allProducts = await storage.getProductsByStore(product.storeId);
      const result = await generateBundleSuggestion(product, allProducts);
      
      const suggestion = await storage.createBundleSuggestion({
        storeId: product.storeId,
        productId: product.id,
        bundleName: result.bundleName,
        bundleDescription: result.bundleDescription,
        suggestedProductIds: result.suggestedProductIds,
        discountPercentage: result.discountPercentage,
        confidence: result.confidence,
      });

      res.json(suggestion);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate bundle suggestion" });
    }
  });

  // Generate banner recommendation
  app.post("/api/products/:id/generate-banner", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const result = await generateBannerRecommendation(product);
      
      const recommendation = await storage.createBannerRecommendation({
        storeId: product.storeId,
        productId: product.id,
        bannerType: result.bannerType,
        headline: result.headline,
        subheadline: result.subheadline,
        ctaText: result.ctaText,
        confidence: result.confidence,
      });

      res.json(recommendation);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate banner recommendation" });
    }
  });

  // Generate product badges
  app.post("/api/products/:id/generate-badges", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      const result = await generateBadges(product);
      
      // Auto-apply badges with high confidence
      const badgesToApply = result.badges.filter(b => b.shouldDisplay);
      await storage.updateProduct(product.id, {
        badges: badgesToApply,
      });

      res.json({ badges: badgesToApply, confidence: result.confidence });
    } catch (error) {
      res.status(500).json({ error: "Failed to generate badges" });
    }
  });

  // AI Super Optimize - Generate everything for a specific product
  app.post("/api/products/:id/ai-optimize", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }

      console.log(`🚀 AI Optimizing product: ${product.title}`);

      // 1. Analyze product
      const analysis = await analyzeProduct(product);
      
      // 2. Generate badges
      const badgeResult = await generateBadges(product);
      const badgesToApply = badgeResult.badges.filter(b => b.shouldDisplay);

      // 3. Update product with scores and badges
      await storage.updateProduct(product.id, {
        seoScore: analysis.seoScore,
        aiScore: analysis.aiScore,
        badges: badgesToApply,
        lastAnalyzedAt: new Date(),
      });

      // 4. Generate bundles
      const allProducts = await storage.getProductsByStore(product.storeId);
      let bundleCreated = null;
      if (allProducts.length > 1) {
        const bundleResult = await generateBundleSuggestion(product, allProducts);
        if (bundleResult.suggestedProductIds.length > 0 && bundleResult.confidence > 0.5) {
          bundleCreated = await storage.createBundleSuggestion({
            storeId: product.storeId,
            productId: product.id,
            bundleName: bundleResult.bundleName,
            bundleDescription: bundleResult.bundleDescription,
            suggestedProductIds: bundleResult.suggestedProductIds,
            discountPercentage: bundleResult.discountPercentage,
            confidence: bundleResult.confidence,
            status: bundleResult.confidence > 0.75 ? "applied" : "pending",
          });
        }
      }

      // 5. Generate banner
      const bannerResult = await generateBannerRecommendation(product);
      let bannerCreated = null;
      if (bannerResult.confidence > 0.6) {
        bannerCreated = await storage.createBannerRecommendation({
          storeId: product.storeId,
          productId: product.id,
          bannerType: bannerResult.bannerType,
          headline: bannerResult.headline,
          subheadline: bannerResult.subheadline,
          ctaText: bannerResult.ctaText,
          confidence: bannerResult.confidence,
          status: bannerResult.confidence > 0.75 ? "applied" : "pending",
        });
      }

      res.json({
        success: true,
        analysis: {
          seoScore: analysis.seoScore,
          aiScore: analysis.aiScore,
          issuesFound: analysis.issues.length,
        },
        badges: badgesToApply,
        bundle: bundleCreated,
        banner: bannerCreated,
      });
    } catch (error) {
      console.error("AI optimization error:", error);
      res.status(500).json({ error: "Failed to AI optimize product" });
    }
  });

  // ============ ISSUES ============
  
  // Get all issues
  app.get("/api/issues", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      const productId = req.query.productId as string;
      
      let issues;
      if (productId) {
        issues = await storage.getIssuesByProduct(productId);
      } else if (storeId) {
        issues = await storage.getIssuesByStore(storeId);
      } else {
        issues = await storage.getIssues();
      }
      res.json(issues);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch issues" });
    }
  });

  // Get single issue
  app.get("/api/issues/:id", async (req, res) => {
    try {
      const issue = await storage.getIssue(req.params.id);
      if (!issue) {
        return res.status(404).json({ error: "Issue not found" });
      }
      res.json(issue);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch issue" });
    }
  });

  // Update issue
  app.patch("/api/issues/:id", async (req, res) => {
    try {
      const issue = await storage.updateIssue(req.params.id, req.body);
      if (!issue) {
        return res.status(404).json({ error: "Issue not found" });
      }
      res.json(issue);
    } catch (error) {
      res.status(500).json({ error: "Failed to update issue" });
    }
  });

  // Auto-fix issue with AI
  app.post("/api/issues/:id/fix", async (req, res) => {
    try {
      const issue = await storage.getIssue(req.params.id);
      if (!issue) {
        return res.status(404).json({ error: "Issue not found" });
      }
      if (!issue.autoFixable) {
        return res.status(400).json({ error: "This issue cannot be auto-fixed" });
      }
      if (!issue.productId) {
        return res.status(400).json({ error: "Issue has no associated product" });
      }

      const product = await storage.getProduct(issue.productId);
      if (!product) {
        return res.status(404).json({ error: "Associated product not found" });
      }

      const fix = await fixIssue(
        { type: issue.type, description: issue.description || "" },
        product
      );

      // Create improvement from fix
      const improvement = await storage.createImprovement({
        storeId: issue.storeId,
        productId: issue.productId,
        type: fix.type,
        originalContent: fix.type === "tags" 
          ? product.tags?.join(", ") || ""
          : fix.type === "title" 
            ? product.title 
            : product.description || "",
        improvedContent: fix.content,
        confidence: fix.confidence,
      });

      // Mark issue as resolved when auto-fixed
      await storage.updateIssue(issue.id, { 
        status: "resolved",
        resolvedAt: new Date() 
      });

      // Update store stats
      const allIssues = await storage.getIssuesByStore(issue.storeId);
      const openIssues = allIssues.filter(i => i.status === "open");
      const allProducts = await storage.getProductsByStore(issue.storeId);
      const healthScore = Math.max(0, 100 - (openIssues.length * 10));
      
      await storage.updateStore(issue.storeId, {
        activeIssues: openIssues.length,
        healthScore,
      });

      res.json({ improvement, issue: await storage.getIssue(issue.id) });
    } catch (error) {
      console.error("Fix error:", error);
      res.status(500).json({ error: "Failed to fix issue" });
    }
  });

  // ============ IMPROVEMENTS ============
  
  // Get all improvements
  app.get("/api/improvements", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      const productId = req.query.productId as string;
      
      let improvements;
      if (productId) {
        improvements = await storage.getImprovementsByProduct(productId);
      } else if (storeId) {
        improvements = await storage.getImprovementsByStore(storeId);
      } else {
        improvements = await storage.getImprovements();
      }
      res.json(improvements);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch improvements" });
    }
  });

  // Update improvement (apply/reject)
  app.patch("/api/improvements/:id", async (req, res) => {
    try {
      const { status } = req.body;
      const improvement = await storage.getImprovement(req.params.id);
      
      if (!improvement) {
        return res.status(404).json({ error: "Improvement not found" });
      }

      if (status === "applied" && improvement.productId) {
        // Apply the improvement to the product
        const product = await storage.getProduct(improvement.productId);
        if (product) {
          const updateData: Record<string, any> = {};
          
          if (improvement.type === "description") {
            updateData.description = improvement.improvedContent;
            updateData.hasDescription = true;
          } else if (improvement.type === "tags") {
            updateData.tags = improvement.improvedContent.split(", ").map(t => t.trim());
            updateData.hasTags = true;
          } else if (improvement.type === "title") {
            updateData.title = improvement.improvedContent;
          }

          await storage.updateProduct(product.id, updateData);

          // Resolve related issues
          const issues = await storage.getIssuesByProduct(product.id);
          for (const issue of issues) {
            if (
              (improvement.type === "description" && issue.type === "missing_description") ||
              (improvement.type === "tags" && issue.type === "missing_tags")
            ) {
              await storage.updateIssue(issue.id, { 
                status: "resolved", 
                resolvedAt: new Date() 
              });
            }
          }
        }
      }

      const updated = await storage.updateImprovement(req.params.id, { 
        status,
        appliedAt: status === "applied" ? new Date() : undefined
      });

      // Update store stats after applying improvement
      if (status === "applied" && improvement.storeId) {
        const allIssues = await storage.getIssuesByStore(improvement.storeId);
        const openIssues = allIssues.filter(i => i.status === "open");
        const allProducts = await storage.getProductsByStore(improvement.storeId);
        const healthScore = Math.max(0, 100 - (openIssues.length * 10));
        
        await storage.updateStore(improvement.storeId, {
          activeIssues: openIssues.length,
          healthScore,
        });
      }

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update improvement" });
    }
  });

  // Apply improvement (shorthand endpoint)
  app.post("/api/improvements/:id/apply", async (req, res) => {
    try {
      const improvement = await storage.getImprovement(req.params.id);
      
      if (!improvement) {
        return res.status(404).json({ error: "Improvement not found" });
      }

      if (improvement.productId) {
        const product = await storage.getProduct(improvement.productId);
        if (product) {
          const updateData: Record<string, any> = {};
          
          if (improvement.type === "description") {
            updateData.description = improvement.improvedContent;
            updateData.hasDescription = true;
          } else if (improvement.type === "tags") {
            updateData.tags = improvement.improvedContent.split(", ").map(t => t.trim());
            updateData.hasTags = true;
          } else if (improvement.type === "title") {
            updateData.title = improvement.improvedContent;
          }

          await storage.updateProduct(product.id, updateData);

          const issues = await storage.getIssuesByProduct(product.id);
          for (const issue of issues) {
            if (
              (improvement.type === "description" && issue.type === "missing_description") ||
              (improvement.type === "tags" && issue.type === "missing_tags")
            ) {
              await storage.updateIssue(issue.id, { 
                status: "resolved", 
                resolvedAt: new Date() 
              });
            }
          }
        }
      }

      const updated = await storage.updateImprovement(req.params.id, { 
        status: "applied",
        appliedAt: new Date()
      });

      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to apply improvement" });
    }
  });

  // ============ BUNDLES ============
  
  app.get("/api/bundles", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      const bundles = storeId 
        ? await storage.getBundleSuggestionsByStore(storeId)
        : await storage.getBundleSuggestions();
      res.json(bundles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bundles" });
    }
  });

  app.patch("/api/bundles/:id", async (req, res) => {
    try {
      const bundle = await storage.updateBundleSuggestion(req.params.id, req.body);
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      res.json(bundle);
    } catch (error) {
      res.status(500).json({ error: "Failed to update bundle" });
    }
  });

  app.post("/api/bundles/:id/apply", async (req, res) => {
    try {
      const bundle = await storage.updateBundleSuggestion(req.params.id, { status: "applied" });
      if (!bundle) {
        return res.status(404).json({ error: "Bundle not found" });
      }
      res.json(bundle);
    } catch (error) {
      res.status(500).json({ error: "Failed to apply bundle" });
    }
  });

  // ============ BANNERS ============
  
  app.get("/api/banners", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      const banners = storeId 
        ? await storage.getBannerRecommendationsByStore(storeId)
        : await storage.getBannerRecommendations();
      res.json(banners);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch banners" });
    }
  });

  app.patch("/api/banners/:id", async (req, res) => {
    try {
      const banner = await storage.updateBannerRecommendation(req.params.id, req.body);
      if (!banner) {
        return res.status(404).json({ error: "Banner not found" });
      }
      res.json(banner);
    } catch (error) {
      res.status(500).json({ error: "Failed to update banner" });
    }
  });

  app.post("/api/banners/:id/apply", async (req, res) => {
    try {
      const banner = await storage.updateBannerRecommendation(req.params.id, { status: "applied" });
      if (!banner) {
        return res.status(404).json({ error: "Banner not found" });
      }
      res.json(banner);
    } catch (error) {
      res.status(500).json({ error: "Failed to apply banner" });
    }
  });

  // ============ ANALYSIS PROGRESS ============
  
  app.get("/api/analysis/progress", async (req, res) => {
    try {
      const { analysisProgress } = await import("./monitor");
      res.json({
        total: analysisProgress.total,
        completed: analysisProgress.completed,
        percentage: analysisProgress.percentage,
        isRunning: analysisProgress.isRunning,
        currentProductId: analysisProgress.currentProductId,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analysis progress" });
    }
  });

  // ============ DASHBOARD ============
  
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const storeId = req.query.storeId as string;
      
      let products, issues, improvements, bundles, banners;
      
      if (storeId) {
        products = await storage.getProductsByStore(storeId);
        issues = await storage.getIssuesByStore(storeId);
        improvements = await storage.getImprovementsByStore(storeId);
        bundles = await storage.getBundleSuggestionsByStore(storeId);
        banners = await storage.getBannerRecommendationsByStore(storeId);
      } else {
        products = await storage.getProducts();
        issues = await storage.getIssues();
        improvements = await storage.getImprovements();
        bundles = await storage.getBundleSuggestions();
        banners = await storage.getBannerRecommendations();
      }

      const openIssues = issues.filter(i => i.status === "open");
      const resolvedIssues = issues.filter(i => i.status === "resolved");
      const pendingImprovements = improvements.filter(i => i.status === "pending");
      const appliedImprovements = improvements.filter(i => i.status === "applied");

      const stats = {
        totalProducts: products.length,
        totalIssues: issues.length,
        openIssues: openIssues.length,
        resolvedIssues: resolvedIssues.length,
        criticalIssues: openIssues.filter(i => i.severity === "critical").length,
        highIssues: openIssues.filter(i => i.severity === "high").length,
        mediumIssues: openIssues.filter(i => i.severity === "medium").length,
        lowIssues: openIssues.filter(i => i.severity === "low").length,
        pendingImprovements: pendingImprovements.length,
        appliedImprovements: appliedImprovements.length,
        totalBundles: bundles.length,
        totalBanners: banners.length,
        healthScore: products.length > 0 
          ? Math.max(0, 100 - (openIssues.length / products.length) * 20) 
          : 100,
        issuesByType: {
          missing_description: openIssues.filter(i => i.type === "missing_description").length,
          missing_images: openIssues.filter(i => i.type === "missing_images").length,
          missing_tags: openIssues.filter(i => i.type === "missing_tags").length,
          low_seo: openIssues.filter(i => i.type === "low_seo").length,
          other: openIssues.filter(i => !["missing_description", "missing_images", "missing_tags", "low_seo"].includes(i.type)).length,
        },
      };

      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  return httpServer;
}
