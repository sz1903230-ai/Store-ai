
import type { Product } from "@shared/schema";

interface ShopifyProduct {
  id: number;
  title: string;
  body_html: string;
  handle: string;
  vendor: string;
  product_type: string;
  tags: string;
  status: string;
  images: Array<{ src: string }>;
  variants: Array<{ price: string; compare_at_price: string | null; inventory_quantity: number }>;
}

export class ShopifyClient {
  constructor(
    private shopDomain: string,
    private accessToken: string
  ) {}

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`https://${this.shopDomain}/admin/api/2024-01/shop.json`, {
        headers: {
          'X-Shopify-Access-Token': this.accessToken,
          'Content-Type': 'application/json',
        },
      });
      return response.ok;
    } catch (error) {
      console.error("Shopify connection test failed:", error);
      return false;
    }
  }

  async getShopInfo(): Promise<{ name: string; domain: string } | null> {
    try {
      const response = await fetch(`https://${this.shopDomain}/admin/api/2024-01/shop.json`, {
        headers: {
          'X-Shopify-Access-Token': this.accessToken,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Shopify API error: ${response.status}`);
      }

      const data = await response.json();
      return {
        name: data.shop.name,
        domain: data.shop.domain,
      };
    } catch (error) {
      console.error("Failed to get shop info:", error);
      return null;
    }
  }

  async getProducts(): Promise<ShopifyProduct[]> {
    try {
      const response = await fetch(`https://${this.shopDomain}/admin/api/2024-01/products.json?limit=250`, {
        headers: {
          'X-Shopify-Access-Token': this.accessToken,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Shopify API error: ${response.status}`);
      }

      const data = await response.json();
      return data.products || [];
    } catch (error) {
      console.error("Failed to fetch products:", error);
      return [];
    }
  }

  async updateProduct(productId: string, updates: {
    body_html?: string;
    tags?: string;
    title?: string;
  }): Promise<boolean> {
    try {
      const response = await fetch(
        `https://${this.shopDomain}/admin/api/2024-01/products/${productId}.json`,
        {
          method: 'PUT',
          headers: {
            'X-Shopify-Access-Token': this.accessToken,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ product: updates }),
        }
      );

      return response.ok;
    } catch (error) {
      console.error("Failed to update product:", error);
      return false;
    }
  }

  convertToLocalProduct(shopifyProduct: ShopifyProduct, storeId: string): Partial<Product> {
    const variant = shopifyProduct.variants[0];
    const tags = shopifyProduct.tags ? shopifyProduct.tags.split(', ').filter(t => t.trim()) : [];
    
    return {
      storeId,
      shopifyId: shopifyProduct.id.toString(),
      title: shopifyProduct.title,
      description: shopifyProduct.body_html || "",
      handle: shopifyProduct.handle,
      vendor: shopifyProduct.vendor,
      productType: shopifyProduct.product_type,
      tags,
      status: shopifyProduct.status,
      imageUrl: shopifyProduct.images[0]?.src,
      images: shopifyProduct.images.map(img => img.src),
      price: variant?.price || "0",
      compareAtPrice: variant?.compare_at_price || null,
      inventoryQuantity: variant?.inventory_quantity || 0,
      hasDescription: !!(shopifyProduct.body_html && shopifyProduct.body_html.trim()),
      hasImages: shopifyProduct.images.length > 0,
      hasTags: tags.length > 0,
    };
  }
}
