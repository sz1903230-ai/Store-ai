import OpenAI from "openai";
import type { Product } from "@shared/schema";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Rate limiting: Track API calls to prevent quota exhaustion
const rateLimiter = {
  calls: [] as number[],
  maxCallsPerMinute: 10, // Adjust based on your OpenAI plan
  canMakeCall(): boolean {
    const now = Date.now();
    this.calls = this.calls.filter(time => now - time < 60000);
    return this.calls.length < this.maxCallsPerMinute;
  },
  recordCall(): void {
    this.calls.push(Date.now());
  }
};

// Cache for analysis results to avoid duplicate API calls
const analysisCache = new Map<string, { result: any, timestamp: number }>();
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

function getCacheKey(product: Product, operation: string): string {
  return `${operation}-${product.id}-${product.updatedAt}`;
}

function getFromCache<T>(key: string): T | null {
  const cached = analysisCache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.result as T;
  }
  analysisCache.delete(key);
  return null;
}

function saveToCache(key: string, result: any): void {
  analysisCache.set(key, { result, timestamp: Date.now() });
}

export interface ProductAnalysis {
  issues: Array<{
    type: string;
    severity: "low" | "medium" | "high" | "critical";
    title: string;
    description: string;
    autoFixable: boolean;
  }>;
  seoScore: number;
  aiScore: number;
  suggestions: string[];
}

export interface DescriptionImprovement {
  improvedDescription: string;
  confidence: number;
  highlights: string[];
}

export interface TagsImprovement {
  tags: string[];
  confidence: number;
}

export interface BundleSuggestionResult {
  bundleName: string;
  bundleDescription: string;
  suggestedProductIds: string[];
  discountPercentage: number;
  confidence: number;
}

export interface BannerRecommendationResult {
  bannerType: "sale" | "new_arrival" | "limited" | "bestseller";
  headline: string;
  subheadline: string;
  ctaText: string;
  confidence: number;
}

export interface BadgeSuggestion {
  badges: Array<{
    type: "discount" | "free_shipping" | "bestseller" | "new_arrival" | "limited_stock" | "eco_friendly";
    text: string;
    color: string;
    shouldDisplay: boolean;
  }>;
  confidence: number;
}

export async function analyzeProduct(product: Product): Promise<ProductAnalysis> {
  // Check cache first
  const cacheKey = getCacheKey(product, "analyze");
  const cached = getFromCache<ProductAnalysis>(cacheKey);
  if (cached) {
    console.log(`Using cached analysis for product ${product.id}`);
    return cached;
  }

  // Check rate limit
  if (!rateLimiter.canMakeCall()) {
    console.warn("Rate limit reached, using fallback analysis");
    return fallbackAnalysis(product);
  }

  const prompt = `Analyze this e-commerce product comprehensively and identify ALL issues, calculate scores, and provide detailed improvement suggestions.

Product Details:
- Title: ${product.title}
- Description: ${product.description || "No description"}
- Tags: ${product.tags?.join(", ") || "No tags"}
- Price: ${product.price || "Not set"}
- Compare At Price: ${product.compareAtPrice || "Not set"}
- Has Images: ${product.hasImages}
- Vendor: ${product.vendor || "Unknown"}
- Product Type: ${product.productType || "Unknown"}
- Inventory: ${product.inventoryQuantity || 0}

Analyze for:
1. Missing/weak content (description, images, tags, title)
2. SEO optimization opportunities
3. Pricing strategy (discounts, psychological pricing)
4. Marketing opportunities (badges, urgency, social proof)
5. Product bundling potential
6. Image quality and quantity
7. Category and tagging optimization

Respond in JSON format:
{
  "issues": [
    {
      "type": "missing_description|missing_images|missing_tags|low_seo|weak_title|missing_price|poor_pricing|missing_badges|no_urgency|poor_categorization",
      "severity": "low|medium|high|critical",
      "title": "Brief issue title",
      "description": "Detailed explanation with specific recommendations",
      "autoFixable": true/false
    }
  ],
  "seoScore": 0-100,
  "aiScore": 0-100,
  "suggestions": ["detailed suggestion 1", "detailed suggestion 2", "..."]
}`;

  try {
    rateLimiter.recordCall();
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini", // Using mini model to save costs
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    const analysis: ProductAnalysis = {
      issues: result.issues || [],
      seoScore: result.seoScore || 50,
      aiScore: result.aiScore || 50,
      suggestions: result.suggestions || [],
    };
    
    saveToCache(cacheKey, analysis);
    return analysis;
  } catch (error: any) {
    console.error("Error analyzing product:", error);
    
    // If quota exceeded, use fallback
    if (error?.status === 429 || error?.code === 'insufficient_quota') {
      console.warn("OpenAI quota exceeded, using fallback analysis");
      return fallbackAnalysis(product);
    }
    
    return fallbackAnalysis(product);
  }
}

// Fallback analysis when API is unavailable - Enhanced version
function fallbackAnalysis(product: Product): ProductAnalysis {
  const issues: any[] = [];
  let seoScore = 100;
  let aiScore = 100;
  const suggestions: string[] = [];

  // Check description
  if (!product.description || product.description.trim().length < 50) {
    issues.push({
      type: "missing_description",
      severity: "high",
      title: "Missing Product Description",
      description: "Add a detailed description highlighting features, benefits, and specifications for better conversions",
      autoFixable: true
    });
    seoScore -= 25;
    aiScore -= 20;
    suggestions.push("Add a compelling product description (minimum 100 words)");
  } else if (product.description.length < 200) {
    issues.push({
      type: "low_seo",
      severity: "medium",
      title: "Short Product Description",
      description: "Expand description to at least 200 characters for better SEO",
      autoFixable: true
    });
    seoScore -= 15;
    aiScore -= 10;
    suggestions.push("Expand product description with more details");
  }

  // Check images
  if (!product.hasImages || !product.images || product.images.length === 0) {
    issues.push({
      type: "missing_images",
      severity: "critical",
      title: "No Product Images",
      description: "Products without images have 85% lower conversion rates. Add at least 3 high-quality images",
      autoFixable: false
    });
    seoScore -= 35;
    aiScore -= 30;
    suggestions.push("Add professional product images (minimum 3)");
  } else if (product.images.length < 3) {
    issues.push({
      type: "missing_images",
      severity: "medium",
      title: "Need More Images",
      description: "Add more product images from different angles to increase customer confidence",
      autoFixable: false
    });
    seoScore -= 15;
    aiScore -= 10;
    suggestions.push("Add more product images (aim for 5+)");
  }

  // Check tags
  if (!product.hasTags || !product.tags || product.tags.length === 0) {
    issues.push({
      type: "missing_tags",
      severity: "medium",
      title: "Missing Tags",
      description: "Tags help customers find your products through search. Add relevant category and feature tags",
      autoFixable: true
    });
    seoScore -= 15;
    aiScore -= 12;
    suggestions.push("Add relevant product tags (minimum 5)");
  } else if (product.tags.length < 5) {
    issues.push({
      type: "missing_tags",
      severity: "low",
      title: "Add More Tags",
      description: "More tags improve discoverability. Aim for 8-12 relevant tags",
      autoFixable: true
    });
    seoScore -= 8;
    aiScore -= 6;
  }

  // Check price
  if (!product.price) {
    issues.push({
      type: "missing_price",
      severity: "critical",
      title: "Missing Price",
      description: "Product must have a price set",
      autoFixable: false
    });
    seoScore -= 40;
    aiScore -= 35;
    suggestions.push("Set product price");
  }

  // Check for discount opportunity
  if (product.price && product.compareAtPrice) {
    const price = parseFloat(product.price);
    const comparePrice = parseFloat(product.compareAtPrice);
    if (comparePrice <= price) {
      issues.push({
        type: "poor_pricing",
        severity: "low",
        title: "Compare Price Issue",
        description: "Compare at price should be higher than regular price to show savings",
        autoFixable: false
      });
      suggestions.push("Adjust compare at price to show discount value");
    }
  }

  // Check inventory
  if ((product.inventoryQuantity || 0) === 0) {
    issues.push({
      type: "no_inventory",
      severity: "high",
      title: "Out of Stock",
      description: "Product has no inventory available",
      autoFixable: false
    });
    suggestions.push("Restock product inventory");
  }

  // Check title quality
  if (product.title.length < 20) {
    issues.push({
      type: "weak_title",
      severity: "medium",
      title: "Short Product Title",
      description: "Product title should be descriptive and include key features",
      autoFixable: true
    });
    seoScore -= 10;
    aiScore -= 8;
    suggestions.push("Expand product title with key features");
  }

  // Positive scoring for good setup
  if (product.description && product.description.length >= 200) {
    seoScore = Math.min(100, seoScore + 10);
    aiScore = Math.min(100, aiScore + 8);
  }
  
  if (product.images && product.images.length >= 5) {
    seoScore = Math.min(100, seoScore + 10);
    aiScore = Math.min(100, aiScore + 10);
  }
  
  if (product.tags && product.tags.length >= 8) {
    seoScore = Math.min(100, seoScore + 8);
    aiScore = Math.min(100, aiScore + 7);
  }

  return {
    issues,
    seoScore: Math.max(0, Math.min(100, seoScore)),
    aiScore: Math.max(0, Math.min(100, aiScore)),
    suggestions: suggestions.length > 0 ? suggestions : ["Product is well optimized! Monitor performance and update regularly."]
  };
}

// Local badge generation without AI
function generateLocalBadges(product: Product): BadgeSuggestion {
  const badges: any[] = [];

  // Discount badge
  if (product.price && product.compareAtPrice) {
    const price = parseFloat(product.price);
    const comparePrice = parseFloat(product.compareAtPrice);
    if (comparePrice > price) {
      const discount = Math.round(((comparePrice - price) / comparePrice) * 100);
      badges.push({
        type: "discount",
        text: `${discount}% OFF`,
        color: "red",
        shouldDisplay: true
      });
    }
  }

  // Free shipping (if price > 500)
  if (product.price && parseFloat(product.price) >= 500) {
    badges.push({
      type: "free_shipping",
      text: "FREE SHIPPING",
      color: "green",
      shouldDisplay: true
    });
  }

  // Limited stock
  if (product.inventoryQuantity && product.inventoryQuantity < 50 && product.inventoryQuantity > 0) {
    badges.push({
      type: "limited_stock",
      text: "LIMITED STOCK",
      color: "orange",
      shouldDisplay: true
    });
  }

  // New arrival (if created recently)
  const createdDate = new Date(product.createdAt);
  const daysSinceCreated = Math.floor((Date.now() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
  if (daysSinceCreated <= 30) {
    badges.push({
      type: "new_arrival",
      text: "NEW ARRIVAL",
      color: "blue",
      shouldDisplay: true
    });
  }

  return {
    badges,
    confidence: 0.9
  };
}

export async function generateBadges(product: Product): Promise<BadgeSuggestion> {
  // Use local badge generation first (faster and free)
  const localBadges = generateLocalBadges(product);
  
  // If we have badges from local generation, return them
  if (localBadges.badges.length > 0) {
    console.log(`Generated ${localBadges.badges.length} badges locally for ${product.title}`);
    return localBadges;
  }

  // Fallback to OpenAI only if needed and quota available
  const prompt = `Generate smart badge recommendations for this product to increase conversions.

Product Details:
- Title: ${product.title}
- Price: ${product.price || "Not set"}
- Compare At Price: ${product.compareAtPrice || "Not set"}
- Inventory: ${product.inventoryQuantity || 0}
- Description: ${product.description || "No description"}
- Vendor: ${product.vendor || "Unknown"}

Analyze and recommend badges:
1. Discount badge - if compareAtPrice > price, calculate % off
2. Free shipping badge - if price suggests free shipping threshold
3. Bestseller badge - based on product characteristics
4. New arrival badge - for fresh/trending products
5. Limited stock badge - if inventory is low (< 20 units)
6. Eco-friendly badge - if product has sustainable attributes

Respond in JSON format:
{
  "badges": [
    {
      "type": "discount|free_shipping|bestseller|new_arrival|limited_stock|eco_friendly",
      "text": "Badge text to display",
      "color": "red|green|blue|yellow|purple|orange",
      "shouldDisplay": true/false
    }
  ],
  "confidence": 0.0-1.0
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      badges: result.badges || [],
      confidence: result.confidence || 0.8,
    };
  } catch (error) {
    console.error("Error generating badges with AI, using local fallback:", error);
    return localBadges; // Return local badges on error
  }
}

export async function generateDescription(product: Product): Promise<DescriptionImprovement> {
  const prompt = `Generate an improved, SEO-optimized product description for this e-commerce product.

Product Details:
- Title: ${product.title}
- Current Description: ${product.description || "No description"}
- Tags: ${product.tags?.join(", ") || "No tags"}
- Price: ${product.price || "Not set"}
- Vendor: ${product.vendor || "Unknown"}
- Product Type: ${product.productType || "Unknown"}

Create a compelling, detailed description that:
1. Highlights key features and benefits
2. Uses persuasive language
3. Includes relevant keywords for SEO
4. Is 2-4 paragraphs long

Respond in JSON format:
{
  "improvedDescription": "The full improved description",
  "confidence": 0.0-1.0,
  "highlights": ["key improvement 1", "key improvement 2"]
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      improvedDescription: result.improvedDescription || "",
      confidence: result.confidence || 0.8,
      highlights: result.highlights || [],
    };
  } catch (error) {
    console.error("Error generating description:", error);
    return {
      improvedDescription: "",
      confidence: 0,
      highlights: [],
    };
  }
}

export async function generateTags(product: Product): Promise<TagsImprovement> {
  const prompt = `Generate optimized tags/keywords for this e-commerce product.

Product Details:
- Title: ${product.title}
- Description: ${product.description || "No description"}
- Current Tags: ${product.tags?.join(", ") || "No tags"}
- Vendor: ${product.vendor || "Unknown"}
- Product Type: ${product.productType || "Unknown"}

Generate 8-15 relevant, SEO-friendly tags that:
1. Include primary product category
2. Include material/style descriptors
3. Include use cases
4. Include trending search terms

Respond in JSON format:
{
  "tags": ["tag1", "tag2", "tag3"],
  "confidence": 0.0-1.0
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      tags: result.tags || [],
      confidence: result.confidence || 0.8,
    };
  } catch (error) {
    console.error("Error generating tags:", error);
    return {
      tags: [],
      confidence: 0,
    };
  }
}

// Local bundle generation logic
function generateLocalBundle(mainProduct: Product, allProducts: Product[]): BundleSuggestionResult {
  const otherProducts = allProducts.filter(p => p.id !== mainProduct.id && p.status === 'active');
  
  // Score products for bundling compatibility
  const scoredProducts = otherProducts.map(p => {
    let score = 0;
    
    // Same category/type
    if (p.productType && mainProduct.productType && p.productType === mainProduct.productType) {
      score += 30;
    }
    
    // Similar price range (within 50% difference)
    if (p.price && mainProduct.price) {
      const priceRatio = parseFloat(p.price) / parseFloat(mainProduct.price);
      if (priceRatio > 0.5 && priceRatio < 1.5) {
        score += 20;
      }
    }
    
    // Shared tags
    const sharedTags = (p.tags || []).filter(tag => (mainProduct.tags || []).includes(tag));
    score += sharedTags.length * 10;
    
    // Same vendor
    if (p.vendor && mainProduct.vendor && p.vendor === mainProduct.vendor) {
      score += 15;
    }
    
    return { product: p, score };
  }).sort((a, b) => b.score - a.score);
  
  // Select top 2-3 products
  const selectedProducts = scoredProducts.slice(0, 3).map(s => s.product.id);
  
  if (selectedProducts.length === 0) {
    return {
      bundleName: "",
      bundleDescription: "",
      suggestedProductIds: [],
      discountPercentage: 10,
      confidence: 0
    };
  }
  
  return {
    bundleName: `${mainProduct.title} Bundle`,
    bundleDescription: `Get ${mainProduct.title} together with complementary items and save!`,
    suggestedProductIds: selectedProducts,
    discountPercentage: 15,
    confidence: 0.8
  };
}

export async function generateBundleSuggestion(
  mainProduct: Product,
  allProducts: Product[]
): Promise<BundleSuggestionResult> {
  // Try local generation first
  const localBundle = generateLocalBundle(mainProduct, allProducts);
  
  if (localBundle.suggestedProductIds.length > 0) {
    console.log(`Generated bundle locally for ${mainProduct.title} with ${localBundle.suggestedProductIds.length} products`);
    return localBundle;
  }
  
  const otherProducts = allProducts.filter(p => p.id !== mainProduct.id).slice(0, 10);
  
  const prompt = `Suggest a product bundle for this main product with complementary items.

Main Product:
- Title: ${mainProduct.title}
- Description: ${mainProduct.description || "No description"}
- Type: ${mainProduct.productType || "Unknown"}
- Price: ${mainProduct.price || "Not set"}

Available Products to Bundle With:
${otherProducts.map(p => `- ID: ${p.id}, Title: ${p.title}, Type: ${p.productType}, Price: ${p.price}`).join("\n")}

Create a bundle suggestion that:
1. Groups complementary products
2. Offers value to customers
3. Increases average order value

Respond in JSON format:
{
  "bundleName": "Creative bundle name",
  "bundleDescription": "Description of the bundle value",
  "suggestedProductIds": ["id1", "id2"],
  "discountPercentage": 10-25,
  "confidence": 0.0-1.0
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      bundleName: result.bundleName || "Product Bundle",
      bundleDescription: result.bundleDescription || "",
      suggestedProductIds: result.suggestedProductIds || [],
      discountPercentage: result.discountPercentage || 10,
      confidence: result.confidence || 0.7,
    };
  } catch (error) {
    console.error("Error generating bundle with AI, using local fallback:", error);
    return localBundle; // Return local bundle on error
  }
}

// Local banner generation logic
function generateLocalBanner(product: Product): BannerRecommendationResult {
  let bannerType: "sale" | "new_arrival" | "limited" | "bestseller" = "new_arrival";
  let headline = product.title;
  let subheadline = "";
  
  // Determine banner type
  if (product.price && product.compareAtPrice && parseFloat(product.compareAtPrice) > parseFloat(product.price)) {
    bannerType = "sale";
    const discount = Math.round(((parseFloat(product.compareAtPrice) - parseFloat(product.price)) / parseFloat(product.compareAtPrice)) * 100);
    headline = `${discount}% OFF ${product.title}`;
    subheadline = `Save ₹${(parseFloat(product.compareAtPrice) - parseFloat(product.price)).toFixed(2)}`;
  } else if (product.inventoryQuantity && product.inventoryQuantity < 50) {
    bannerType = "limited";
    headline = `Limited Stock: ${product.title}`;
    subheadline = `Only ${product.inventoryQuantity} left in stock!`;
  } else {
    const createdDate = new Date(product.createdAt);
    const daysSinceCreated = Math.floor((Date.now() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
    if (daysSinceCreated <= 30) {
      bannerType = "new_arrival";
      headline = `New: ${product.title}`;
      subheadline = "Just arrived! Get it now";
    }
  }
  
  return {
    bannerType,
    headline: headline.substring(0, 60), // Limit headline length
    subheadline: subheadline.substring(0, 80),
    ctaText: "Shop Now",
    confidence: 0.85
  };
}

export async function generateBannerRecommendation(product: Product): Promise<BannerRecommendationResult> {
  // Generate local banner first
  const localBanner = generateLocalBanner(product);
  
  console.log(`Generated banner locally for ${product.title}: ${localBanner.bannerType}`);
  
  // Return local banner (skip AI to save quota)
  return localBanner;
  
  /* AI banner generation disabled to save quota
  const prompt = `Generate promotional banner copy for this e-commerce product.

Product Details:
- Title: ${product.title}
- Description: ${product.description || "No description"}
- Price: ${product.price || "Not set"}
- Compare At Price: ${product.compareAtPrice || "Not set"}
- Vendor: ${product.vendor || "Unknown"}
- Product Type: ${product.productType || "Unknown"}

Create compelling banner content that:
1. Grabs attention
2. Creates urgency
3. Drives conversions

Respond in JSON format:
{
  "bannerType": "sale|new_arrival|limited|bestseller",
  "headline": "Attention-grabbing headline (max 10 words)",
  "subheadline": "Supporting text (max 20 words)",
  "ctaText": "Call to action (2-4 words)",
  "confidence": 0.0-1.0
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      bannerType: result.bannerType || "new_arrival",
      headline: result.headline || "",
      subheadline: result.subheadline || "",
      ctaText: result.ctaText || "Shop Now",
      confidence: result.confidence || 0.75,
    };
  } catch (error) {
    console.error("Error generating banner recommendation:", error);
    return localBanner;
  }
  */
}

export async function fixIssue(
  issue: { type: string; description: string },
  product: Product
): Promise<{ content: string; type: string; confidence: number }> {
  const prompt = `Fix this product issue by generating improved content.

Issue Type: ${issue.type}
Issue Description: ${issue.description}

Product Details:
- Title: ${product.title}
- Description: ${product.description || "No description"}
- Tags: ${product.tags?.join(", ") || "No tags"}
- Price: ${product.price || "Not set"}

Generate the fixed content based on the issue type:
- For missing_description or low_seo: Generate an SEO-optimized description
- For missing_tags: Generate relevant tags as comma-separated list
- For weak_title: Generate an improved title

Respond in JSON format:
{
  "content": "The fixed content",
  "type": "description|tags|title",
  "confidence": 0.0-1.0
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      content: result.content || "",
      type: result.type || "description",
      confidence: result.confidence || 0.8,
    };
  } catch (error) {
    console.error("Error fixing issue:", error);
    return {
      content: "",
      type: "description",
      confidence: 0,
    };
  }
}
